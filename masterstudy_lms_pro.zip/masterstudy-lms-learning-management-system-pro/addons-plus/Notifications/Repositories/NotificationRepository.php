<?php

namespace MasterStudy\Lms\Pro\AddonsPlus\Notifications\Repositories;

final class NotificationRepository {
	public function create( array $data ): int {
		global $wpdb;

		$dedupe_key = isset( $data['dedupe_key'] ) ? (string) $data['dedupe_key'] : '';

		if ( '' !== $dedupe_key ) {
			$existing_id = $this->find_id_by_dedupe_key( $dedupe_key );

			if ( $existing_id > 0 ) {
				return $existing_id;
			}
		}

		$now      = gmdate( 'Y-m-d H:i:s' );
		$inserted = $wpdb->insert(
			masterstudy_lms_notifications_table_name( $wpdb ),
			array(
				'trigger_key'        => sanitize_key( $data['trigger_key'] ?? '' ),
				'title'              => sanitize_text_field( $data['title'] ?? '' ),
				'message'            => sanitize_textarea_field( $data['message'] ?? '' ),
				'context_label'      => sanitize_text_field( $data['context_label'] ?? '' ),
				'course_id'          => absint( $data['course_id'] ?? 0 ),
				'item_id'            => absint( $data['item_id'] ?? 0 ),
				'assignment_id'      => absint( $data['assignment_id'] ?? 0 ),
				'user_assignment_id' => absint( $data['user_assignment_id'] ?? 0 ),
				'actor_user_id'      => absint( $data['actor_user_id'] ?? 0 ),
				'click_action'       => sanitize_key( $data['click_action'] ?? '' ),
				'click_url'          => esc_url_raw( $data['click_url'] ?? '' ),
				'dedupe_key'         => '' !== $dedupe_key ? sanitize_text_field( $dedupe_key ) : null,
				'metadata'           => wp_json_encode( $data['metadata'] ?? array() ),
				'created_at_gmt'     => $now,
			),
			array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return '' !== $dedupe_key ? $this->find_id_by_dedupe_key( $dedupe_key ) : 0;
		}

		return (int) $wpdb->insert_id;
	}

	public function add_recipients( int $notification_id, array $user_ids ): void {
		global $wpdb;

		$user_ids = array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );

		if ( empty( $user_ids ) || $notification_id <= 0 ) {
			return;
		}

		$now   = gmdate( 'Y-m-d H:i:s' );
		$table = masterstudy_lms_notification_recipients_table_name( $wpdb );
		$rows  = array();
		$args  = array();

		foreach ( $user_ids as $user_id ) {
			$rows[] = '(%d,%d,%s)';
			$args[] = $notification_id;
			$args[] = $user_id;
			$args[] = $now;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and value placeholders are generated internally.
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (notification_id,user_id,created_at_gmt) VALUES " . implode( ',', $rows ),
				$args
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
	}

	public function find_id_by_dedupe_key( string $dedupe_key ): int {
		global $wpdb;

		if ( '' === $dedupe_key ) {
			return 0;
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT id FROM ' . masterstudy_lms_notifications_table_name( $wpdb ) . ' WHERE dedupe_key = %s LIMIT 1',
				$dedupe_key
			)
		);
	}

	public function get_for_user( int $user_id, int $page = 1, int $per_page = 20, bool $unread_only = false, int $limit = 0 ): array {
		global $wpdb;

		$page     = max( 1, $page );
		$per_page = min( 50, max( 1, $per_page ) );
		$limit    = $limit > 0 ? min( 51, max( 1, $limit ) ) : $per_page;
		$offset   = ( $page - 1 ) * $per_page;
		$where    = 'r.user_id = %d';
		$params   = array( $user_id );

		if ( $unread_only ) {
			$where .= ' AND r.read_at_gmt IS NULL';
		}

		$params[] = $limit;
		$params[] = $offset;

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Table names and optional WHERE fragment are generated internally.
		$results = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT r.id AS recipient_id, r.user_id, r.read_at_gmt, r.created_at_gmt AS recipient_created_at_gmt,
					n.id AS notification_id, n.trigger_key, n.title, n.message, n.context_label, n.course_id, n.item_id,
					n.assignment_id, n.user_assignment_id, n.actor_user_id, n.click_action, n.click_url, n.metadata, n.created_at_gmt
				FROM ' . masterstudy_lms_notification_recipients_table_name( $wpdb ) . ' r
				INNER JOIN ' . masterstudy_lms_notifications_table_name( $wpdb ) . " n ON n.id = r.notification_id
				WHERE {$where}
				ORDER BY r.created_at_gmt DESC, r.id DESC
				LIMIT %d OFFSET %d",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return $results;
	}

	public function unread_count( int $user_id ): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT COUNT(*) FROM ' . masterstudy_lms_notification_recipients_table_name( $wpdb ) . ' WHERE user_id = %d AND read_at_gmt IS NULL',
				$user_id
			)
		);
	}

	public function mark_read( int $recipient_id, int $user_id ): bool {
		global $wpdb;

		if ( $recipient_id <= 0 || $user_id <= 0 ) {
			return false;
		}

		$recipient = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT id, read_at_gmt FROM ' . masterstudy_lms_notification_recipients_table_name( $wpdb ) . ' WHERE id = %d AND user_id = %d LIMIT 1',
				$recipient_id,
				$user_id
			),
			ARRAY_A
		);

		if ( ! is_array( $recipient ) ) {
			return false;
		}

		if ( ! empty( $recipient['read_at_gmt'] ) ) {
			return true;
		}

		$updated = $wpdb->update(
			masterstudy_lms_notification_recipients_table_name( $wpdb ),
			array( 'read_at_gmt' => gmdate( 'Y-m-d H:i:s' ) ),
			array(
				'id'      => $recipient_id,
				'user_id' => $user_id,
			),
			array( '%s' ),
			array( '%d', '%d' )
		);

		return false !== $updated;
	}

	public function get_recipient_read_state( int $notification_id, int $user_id ): ?array {
		global $wpdb;

		if ( $notification_id <= 0 || $user_id <= 0 ) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT id, read_at_gmt FROM ' . masterstudy_lms_notification_recipients_table_name( $wpdb ) . ' WHERE notification_id = %d AND user_id = %d LIMIT 1',
				$notification_id,
				$user_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	public function mark_all_read( int $user_id ): int {
		global $wpdb;

		if ( $user_id <= 0 ) {
			return 0;
		}

		return (int) $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'UPDATE ' . masterstudy_lms_notification_recipients_table_name( $wpdb ) . ' SET read_at_gmt = %s WHERE user_id = %d AND read_at_gmt IS NULL',
				gmdate( 'Y-m-d H:i:s' ),
				$user_id
			)
		);
	}

	public function get_notification( int $notification_id ): ?array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Table name is generated from $wpdb->prefix.
				'SELECT * FROM ' . masterstudy_lms_notifications_table_name( $wpdb ) . ' WHERE id = %d LIMIT 1',
				$notification_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	public function get_notifications( array $notification_ids ): array {
		global $wpdb;

		$notification_ids = $this->sanitize_ids( $notification_ids );

		if ( empty( $notification_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $notification_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and IN placeholders are generated internally.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . masterstudy_lms_notifications_table_name( $wpdb ) . " WHERE id IN ({$placeholders})",
				$notification_ids
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$indexed = array();

		foreach ( $rows as $row ) {
			$indexed[ (int) $row['id'] ] = $row;
		}

		return $indexed;
	}

	public function get_recipient_read_states( array $notification_ids, array $user_ids ): array {
		global $wpdb;

		$notification_ids = $this->sanitize_ids( $notification_ids );
		$user_ids         = $this->sanitize_ids( $user_ids );

		if ( empty( $notification_ids ) || empty( $user_ids ) ) {
			return array();
		}

		$table                     = masterstudy_lms_notification_recipients_table_name( $wpdb );
		$notification_placeholders = implode( ',', array_fill( 0, count( $notification_ids ), '%d' ) );
		$user_placeholders         = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
		$params                    = array_merge( $notification_ids, $user_ids );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and IN placeholders are generated internally.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT notification_id, user_id, read_at_gmt
				FROM {$table}
				WHERE notification_id IN ({$notification_placeholders})
					AND user_id IN ({$user_placeholders})",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$states = array();

		foreach ( $rows as $row ) {
			$notification_id = (int) $row['notification_id'];
			$user_id         = (int) $row['user_id'];

			if ( ! isset( $states[ $notification_id ] ) ) {
				$states[ $notification_id ] = array();
			}

			$states[ $notification_id ][ $user_id ] = $row;
		}

		return $states;
	}

	public function find_existing_dedupe_keys( array $dedupe_keys ): array {
		global $wpdb;

		$dedupe_keys = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $dedupe_key ): string {
							return sanitize_text_field( (string) $dedupe_key );
						},
						$dedupe_keys
					)
				)
			)
		);

		if ( empty( $dedupe_keys ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $dedupe_keys ), '%s' ) );

		return array_map(
			'strval',
			$wpdb->get_col(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Table name and IN placeholders are generated internally.
					'SELECT dedupe_key FROM ' . masterstudy_lms_notifications_table_name( $wpdb ) . " WHERE dedupe_key IN ({$placeholders})",
					$dedupe_keys
				)
			)
		);
	}

	private function sanitize_ids( array $ids ): array {
		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}
}
