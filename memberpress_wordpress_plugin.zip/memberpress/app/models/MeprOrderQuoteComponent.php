<?php

defined('ABSPATH') || exit;

/**
 * One priceable component of a checkout state, as the quote builder
 * enumerates it.
 *
 * The builder's enumeration carrier: it projects a transaction (and its
 * subscription when recurring) into the first-period-aware figures the
 * pricing surfaces, the fingerprint, and the line pairing read. Nothing
 * outside the builder constructs or receives one. The projection is a
 * snapshot of the priced inputs: applying a quote line later mutates
 * the backing rows, never the component.
 */
final class MeprOrderQuoteComponent
{
    /**
     * The backing transaction (the row a quote line applies to).
     *
     * @var MeprTransaction
     */
    public MeprTransaction $transaction;

    /**
     * The backing subscription when the component is a first period.
     *
     * @var MeprSubscription|null
     */
    public ?MeprSubscription $subscription;

    /**
     * Whether this is the main product's component.
     *
     * @var boolean
     */
    public bool $is_main;

    /**
     * The component's position among the kept components.
     *
     * @var integer
     */
    public int $position;

    /**
     * The line kind, one of the MeprOrderQuoteLine::KIND_* constants.
     *
     * @var string
     */
    public string $kind;

    /**
     * The product the component charges for.
     *
     * @var integer
     */
    public int $product_id;

    /**
     * Whether the backing row is unsaved (no persistent reference yet).
     *
     * @var boolean
     */
    public bool $unsaved;

    /**
     * The persistent reference (txn_{id} or sub_{id}_first_period).
     *
     * @var string
     */
    public string $reference;

    /**
     * The projected pre-tax amount for the first charge.
     *
     * @var float
     */
    public float $amount;

    /**
     * The projected tax for the first charge.
     *
     * @var float
     */
    public float $tax_amount;

    /**
     * The projected gross total for the first charge.
     *
     * @var float
     */
    public float $total;

    /**
     * The prepared blended tax rate.
     *
     * @var float
     */
    public float $tax_rate;

    /**
     * The prepared blended tax description.
     *
     * @var string
     */
    public string $tax_desc;

    /**
     * The prepared blended tax class.
     *
     * @var string
     */
    public string $tax_class;

    /**
     * The prepared reverse-charge reversal amount.
     *
     * @var float
     */
    public float $tax_reversal_amount;

    /**
     * Constructor for the MeprOrderQuoteComponent class.
     *
     * Projects the first-period-aware figures: a trial subscription
     * contributes its trial trio, a non-trial subscription its first
     * period (price and total), and a one-time row its own figures.
     *
     * @param MeprTransaction       $transaction  The backing transaction.
     * @param MeprSubscription|null $subscription The subscription when recurring.
     * @param boolean               $is_main      Whether this is the main product's component.
     * @param integer               $position     The position among kept components.
     */
    public function __construct(MeprTransaction $transaction, ?MeprSubscription $subscription, bool $is_main, int $position)
    {
        $this->transaction  = $transaction;
        $this->subscription = $subscription;
        $this->is_main      = $is_main;
        $this->position     = $position;
        $this->product_id   = (int) $transaction->product_id;

        if (!$subscription instanceof MeprSubscription) {
            $this->kind                = $is_main ? MeprOrderQuoteLine::KIND_MAIN : MeprOrderQuoteLine::KIND_BUMP;
            $this->reference           = "txn_$transaction->id";
            $this->unsaved             = $transaction->id <= 0;
            $this->amount              = (float) $transaction->amount;
            $this->tax_amount          = (float) $transaction->tax_amount;
            $this->total               = (float) $transaction->total;
            $this->tax_rate            = (float) $transaction->tax_rate;
            $this->tax_desc            = (string) $transaction->tax_desc;
            $this->tax_class           = (string) $transaction->tax_class;
            $this->tax_reversal_amount = (float) $transaction->tax_reversal_amount;

            return;
        }

        $this->reference = "sub_{$subscription->id}_first_period";
        $this->unsaved   = $subscription->id <= 0;
        $this->tax_rate  = (float) $subscription->tax_rate;
        $this->tax_desc  = (string) $subscription->tax_desc;
        $this->tax_class = (string) $subscription->tax_class;

        if ($subscription->trial && $subscription->trial_days > 0) {
            $this->kind                = MeprOrderQuoteLine::KIND_TRIAL_CHARGE;
            $this->amount              = (float) $subscription->trial_amount;
            $this->tax_amount          = (float) $subscription->trial_tax_amount;
            $this->total               = (float) $subscription->trial_total;
            $this->tax_reversal_amount = (float) $subscription->trial_tax_reversal_amount;

            return;
        }

        $this->kind                = MeprOrderQuoteLine::KIND_FIRST_PERIOD;
        $this->amount              = (float) $subscription->price;
        $this->tax_amount          = (float) $subscription->tax_amount;
        $this->total               = (float) $subscription->total;
        $this->tax_reversal_amount = (float) $subscription->tax_reversal_amount;
    }

    /**
     * The line reference for a quote stage: product-positional at the
     * preview stage, the persistent reference at the submit stage.
     *
     * @param  string $stage The quote stage, one of the MeprOrderQuote::STAGE_* constants.
     * @return string
     * @throws InvalidArgumentException When a submit-stage component is unsaved.
     */
    public function line_reference(string $stage): string
    {
        if ($stage !== MeprOrderQuote::STAGE_SUBMIT) {
            return "prd_{$this->product_id}_$this->position";
        }

        if ($this->unsaved) {
            throw new InvalidArgumentException('A submit-stage quote requires saved transactions.'); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- constant message, not rendered output.
        }

        return $this->reference;
    }
}
