<?php

namespace BitApps\IntegrationsPro\Actions\MasterStudyLms;

use MasterStudy\Lms\Repositories\CurriculumMaterialRepository;
use MasterStudy\Lms\Repositories\StudentsRepository;
use STM_LMS_Course;
use STM_LMS_Lesson;
use STM_LMS_User_Manager_Course_User;

if (!\defined('ABSPATH')) {
    exit;
}

final class MasterStudyLmsProHelper
{
    public static function enrollUser($response, $data)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('This action requires MasterStudy LMS 3.0 or newer', 'bit-integrations-pro'));
        }

        $courseId = (int) ($data['course_id'] ?? 0);

        if ($courseId <= 0) {
            return self::errorResponse(__('A valid course is required', 'bit-integrations-pro'));
        }

        $email = isset($data['email']) && \is_string($data['email']) ? trim($data['email']) : '';
        $userId = $email ? email_exists($email) : false;

        if (!$userId) {
            return self::errorResponse(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $students = new StudentsRepository();

        if ($students->is_student_enrolled_in_course($courseId, (int) $userId)) {
            return self::errorResponse(__('User already enrolled in course', 'bit-integrations-pro'));
        }

        $result = $students->add_student($courseId, ['email' => $email]);

        if (empty($result['is_enrolled'])) {
            return self::errorResponse(__('Failed to enroll user in course', 'bit-integrations-pro'));
        }

        return self::successResponse(__('User enrolled in course successfully', 'bit-integrations-pro'), ['user_id' => (int) $userId, 'course_id' => $courseId]);
    }

    public static function unenrollUser($response, $data)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('This action requires MasterStudy LMS 3.0 or newer', 'bit-integrations-pro'));
        }

        $courseId = (int) ($data['course_id'] ?? 0);

        if ($courseId <= 0) {
            return self::errorResponse(__('A valid course is required', 'bit-integrations-pro'));
        }

        $email = isset($data['email']) && \is_string($data['email']) ? trim($data['email']) : '';
        $userId = $email ? email_exists($email) : false;

        if (!$userId) {
            return self::errorResponse(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $students = new StudentsRepository();

        if (!$students->is_student_enrolled_in_course($courseId, (int) $userId)) {
            return self::errorResponse(__('User is not enrolled in course', 'bit-integrations-pro'));
        }

        $students->delete_student_by_course($courseId, (int) $userId);

        return self::successResponse(__('User unenrolled from course successfully', 'bit-integrations-pro'), ['user_id' => (int) $userId, 'course_id' => $courseId]);
    }

    public static function markCourseComplete($response, $data)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('This action requires MasterStudy LMS 3.0 or newer', 'bit-integrations-pro'));
        }

        $courseId = (int) ($data['course_id'] ?? 0);

        if ($courseId <= 0) {
            return self::errorResponse(__('A valid course is required', 'bit-integrations-pro'));
        }

        $email = isset($data['email']) && \is_string($data['email']) ? trim($data['email']) : '';
        $userId = $email ? email_exists($email) : false;

        if (!$userId) {
            return self::errorResponse(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $userId = (int) $userId;

        $materialIds = (new CurriculumMaterialRepository())->get_course_materials($courseId);

        if (empty($materialIds)) {
            return self::errorResponse(__('Course does not have any lessons or quizzes added', 'bit-integrations-pro'));
        }

        $students = new StudentsRepository();

        if (!$students->is_student_enrolled_in_course($courseId, $userId)) {
            $enrolled = $students->add_student($courseId, ['email' => $email]);
            if (empty($enrolled['is_enrolled'])) {
                return self::errorResponse(__('Failed to enroll user in course', 'bit-integrations-pro'));
            }
        }

        self::completeMaterials($courseId, $userId, $materialIds);

        return self::successResponse(__('Course marked complete successfully', 'bit-integrations-pro'), ['user_id' => $userId, 'course_id' => $courseId]);
    }

    public static function markLessonComplete($response, $data)
    {
        if (!self::isPluginInstalled()) {
            return self::errorResponse(__('This action requires MasterStudy LMS 3.0 or newer', 'bit-integrations-pro'));
        }

        $courseId = (int) ($data['course_id'] ?? 0);
        $lessonId = (int) ($data['lesson_id'] ?? 0);

        if ($courseId <= 0 || $lessonId <= 0) {
            return self::errorResponse(__('A valid course and lesson are required', 'bit-integrations-pro'));
        }

        $email = isset($data['email']) && \is_string($data['email']) ? trim($data['email']) : '';
        $userId = $email ? email_exists($email) : false;

        if (!$userId) {
            return self::errorResponse(__('User not found with the provided email', 'bit-integrations-pro'));
        }

        $userId = (int) $userId;

        $students = new StudentsRepository();

        if (!$students->course_has_material($courseId, $lessonId)) {
            return self::errorResponse(__('Lesson not found in the selected course', 'bit-integrations-pro'));
        }

        if (!$students->is_student_enrolled_in_course($courseId, $userId)) {
            $enrolled = $students->add_student($courseId, ['email' => $email]);
            if (empty($enrolled['is_enrolled'])) {
                return self::errorResponse(__('Failed to enroll user in course', 'bit-integrations-pro'));
            }
        }

        // complete_lesson() is a toggle, so only fire it when the lesson is not already complete.
        if (!STM_LMS_Lesson::is_lesson_completed($userId, $courseId, $lessonId)) {
            STM_LMS_User_Manager_Course_User::complete_lesson($userId, $courseId, $lessonId);
            STM_LMS_Course::update_course_progress($userId, $courseId);
        }

        return self::successResponse(__('Lesson marked complete successfully', 'bit-integrations-pro'), ['user_id' => $userId, 'course_id' => $courseId, 'lesson_id' => $lessonId]);
    }

    /**
     * Mark every given material complete for the student with a single
     * course-progress recomputation.
     *
     * Lessons use a guarded complete_lesson() because the native call is a
     * toggle (it would un-complete an already-completed lesson). Progress is
     * recomputed once at the end instead of once per material.
     *
     * @param int   $courseId
     * @param int   $userId
     * @param int[] $materialIds
     */
    private static function completeMaterials($courseId, $userId, array $materialIds)
    {
        foreach ($materialIds as $materialId) {
            $materialId = (int) $materialId;

            switch (get_post_type($materialId)) {
                case 'stm-lessons':
                    if (!STM_LMS_Lesson::is_lesson_completed($userId, $courseId, $materialId)) {
                        STM_LMS_User_Manager_Course_User::complete_lesson($userId, $courseId, $materialId);
                    }

                    break;
                case 'stm-assignments':
                    STM_LMS_User_Manager_Course_User::complete_assignment($userId, $courseId, $materialId, true);

                    break;
                case 'stm-quizzes':
                    STM_LMS_User_Manager_Course_User::complete_quiz($userId, $courseId, $materialId, true);

                    break;
            }
        }

        STM_LMS_Course::update_course_progress($userId, $courseId);
    }

    private static function isPluginInstalled()
    {
        return class_exists('MasterStudy\Lms\Repositories\StudentsRepository')
            && class_exists('MasterStudy\Lms\Repositories\CurriculumMaterialRepository')
            && class_exists('STM_LMS_Lesson')
            && class_exists('STM_LMS_User_Manager_Course_User')
            && class_exists('STM_LMS_Course');
    }

    private static function successResponse($message, $data = [])
    {
        return [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ];
    }

    private static function errorResponse($message)
    {
        return [
            'success' => false,
            'message' => $message,
        ];
    }
}
