<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

abstract class MeprBasePayPalGateway extends MeprBaseRealGateway
{
    /**
     * Validate PayPal IPN request
     *
     * @return boolean True if valid, false otherwise
     */
    public function validate_ipn()
    {
        // Set the command that is used to validate the message.
        $_POST['cmd'] = '_notify-validate';

        // We need to send the message back to PayPal just as we received it.
        $params = [
            'method'      => 'POST',
            'body'        => stripslashes_deep($_POST),
            'headers'     => ['connection' => 'close'],
            'httpversion' => 1.1,
            'sslverify'   => true,
            'user-agent'  => 'MemberPress/' . MEPR_VERSION,
            'timeout'     => 30,
        ];

        $this->email_status("POST ARRAY SENDING TO PAYPAL\n" . MeprUtils::object_to_string($params, true) . "\n", $this->settings->debug);

        if (!function_exists('wp_remote_post')) {
            require_once(ABSPATH . WPINC . '/http.php');
        }

        $resp = wp_remote_post($this->settings->url, $params);

        // Put the $_POST data back to how it was so we can pass it to the action.
        unset($_POST['cmd']);

        // If the response was valid, check to see if the request was valid.
        if (
            !is_wp_error($resp) &&
            $resp['response']['code'] >= 200 &&
            $resp['response']['code'] < 300 &&
            (strcmp($resp['body'], 'VERIFIED') === 0)
        ) {
            return true;
        }

        $this->email_status(
            "IPN Verification Just failed:\nIPN:\n" .
                        MeprUtils::object_to_string($_POST, true) .
                        "PayPal Response:\n" .
                        MeprUtils::object_to_string($resp),
            $this->settings->debug
        );
        return false;
    }

    /**
     * Get the time PayPal stamped on the notification being processed.
     *
     * Payment notifications carry the payment time as payment_date and signup
     * notifications carry the subscription start as subscr_date. PayPal retries
     * a failed delivery for days, so both can be well before the notification
     * arrives. The current time is used when neither date can be parsed.
     *
     * @return integer The Unix timestamp.
     */
    protected function get_ipn_timestamp(): int
    {
        foreach (['payment_date', 'subscr_date'] as $key) {
            if (empty($_POST[$key])) {
                continue;
            }

            $timestamp = strtotime(sanitize_text_field(wp_unslash($_POST[$key])));

            if ($timestamp !== false) {
                return $timestamp;
            }
        }

        return time();
    }

    /**
     * Whether PayPal treats the site currency as zero-decimal.
     *
     * PayPal rejects decimal amounts for HUF, JPY, and TWD. The shared
     * MeprCurrencyService list is Stripe-aligned (HUF and TWD are 2-decimal
     * there), so those two must be treated as zero-decimal here. JPY is
     * already on the shared list.
     *
     * @see https://developer.paypal.com/api/rest/reference/currency-codes/
     *
     * @return boolean True when PayPal requires a whole-number amount.
     */
    public static function is_zero_decimal_currency()
    {
        $currency = MeprOptions::fetch()->currency_code;

        // PayPal rejects decimals for these two; the Stripe-aligned list calls both 2-decimal.
        if (in_array(strtoupper($currency), ['HUF', 'TWD'], true)) {
            return true;
        }

        // PayPal charges the site primary only. Pass it in so Utils does not
        // resolve via get_active_currency() (cart session / cookie).
        return MeprUtils::is_zero_decimal_currency($currency);
    }

    /**
     * Format a currency amount for PayPal Standard (a3/a1 fields).
     *
     * Uses the PayPal zero-decimal set and formats those amounts with 0
     * decimals. MeprAppHelper follows the Stripe-aligned list, so it cannot
     * be used here for HUF or TWD.
     *
     * @param float $amount The amount to format.
     *
     * @return string Formatted amount.
     */
    public function format_currency($amount)
    {
        if (self::is_zero_decimal_currency()) {
            $amount = (string) MeprUtils::format_float($amount, 0);
            return str_replace([',', '.'], ['', ''], $amount); // Strip leftover grouping/decimal marks.
        }

        return MeprUtils::format_float($amount);
    }

    /**
     * Process thank you URL redirect
     *
     * @param array           $query_params The query parameters.
     * @param MeprTransaction $txn          The transaction object.
     *
     * @return string The thank you URL
     */
    public function do_thankyou_url($query_params, $txn)
    {
        $mepr_options                   = MeprOptions::fetch();
        $query_params['transaction_id'] = $txn->id;
        return $mepr_options->thankyou_page_url(build_query($query_params));
    }
}
