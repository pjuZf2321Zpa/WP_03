<?php

/**
 * @author WP Cloud Plugins
 * @copyright Copyright (c) 2023, WP Cloud Plugins
 *
 * @since       3.0
 * @see https://www.wpcloudplugins.com
 */

namespace TheLion\OutoftheBox;

defined('ABSPATH') || exit;

class Import
{
    /**
     * Entry object representing the file to be imported.
     *
     * @var Entry
     */
    public $entry;

    /**
     * @var string the name of the attachment
     */
    public $attachment_name;

    /**
     * URL to download the file.
     *
     * @var string
     */
    public $download_url;

    /**
     * Path where the file will be imported.
     *
     * @var string
     */
    public $import_path;

    /**
     * The single instance of the class.
     *
     * @var Import
     */
    protected static $_instance;

    /**
     * Validated file type from the pre-write allowlist check.
     *
     * @var array<string, string>
     */
    protected $validated_file_type = [];

    /**
     * Constructor.
     */
    public function __construct()
    {
        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH.'wp-admin/includes/image.php';

            include_once ABSPATH.'wp-admin/includes/media.php';
        }
    }

    /**
     * Get the single instance of the class.
     *
     * @return Import - Import instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Add a file to the media library.
     *
     * @param mixed $entry
     *
     * @return bool|int attachment ID
     */
    public function add_to_media_library($entry)
    {
        $this->entry = $entry;
        $this->validated_file_type = [];
        $this->import_path = null;

        if (apply_filters('outofthebox_import_require_capability', true, $entry)
            && !current_user_can('upload_files')) {
            Helpers::log_error('Import rejected: insufficient capabilities', 'Import', ['file' => $entry->get_name()], __LINE__);

            return false;
        }

        // Set Attachment name
        $this->attachment_name = sanitize_file_name($entry->get_name());

        // Set Download Url
        $this->download_url = Client::instance()->get_temporarily_link($entry);

        if (empty($this->download_url)) {
            return;
        }

        if (false === $this->download_file_to_uploads()) {
            return false;
        }

        return $this->insert_attachment_to_library();
    }

    /**
     * Download the file to the uploads folder.
     *
     * @return bool false when the file was rejected or could not be stored
     */
    public function download_file_to_uploads()
    {
        $upload_dir = wp_upload_dir();

        if (!empty($upload_dir['error'])) {
            Helpers::log_error('Upload directory not available', 'Import', ['error' => $upload_dir['error']], __LINE__);

            return false;
        }

        // 1. Reject disallowed filetypes BEFORE touching the filesystem.
        $allowed_mimes = apply_filters('outofthebox_import_allowed_mime_types', get_allowed_mime_types());
        $filetype = wp_check_filetype($this->attachment_name, $allowed_mimes);

        if (empty($filetype['ext']) || empty($filetype['type'])) {
            Helpers::log_error(
                'Import rejected: filetype not allowed',
                'Import',
                ['file' => $this->attachment_name],
                __LINE__
            );

            return false;
        }

        $this->validated_file_type = [
            'ext' => (string) $filetype['ext'],
            'type' => (string) $filetype['type'],
        ];

        // 2. Collision-safe filename. time().'_'.$name is not concurrency-safe.
        $filename = wp_unique_filename($upload_dir['path'], $this->attachment_name);
        $target_path = $upload_dir['path'].'/'.$filename;

        // 3. Belt and braces: never write outside the uploads directory.
        $real_dir = realpath($upload_dir['path']);
        if (false === $real_dir || 0 !== strpos(wp_normalize_path($target_path), wp_normalize_path($real_dir).'/')) {
            Helpers::log_error('Import rejected: path outside uploads', 'Import', ['file' => $filename], __LINE__);

            return false;
        }

        // 4. Stream to a temporary file, so a rejected, partial or error-page response never sits in
        //    uploads under a name the webserver might serve.
        $temp_path = wp_tempnam($filename);
        if (empty($temp_path)) {
            Helpers::log_error('Cannot create temp file', 'Import', ['file' => $filename], __LINE__);

            return false;
        }

        Helpers::set_time_limit(0);

        // NOTE: no fopen() here. wp_remote_get() with 'stream' => true opens and writes the file itself.
        //       wp_safe_remote_get() additionally rejects requests to private/internal hosts.
        $response = wp_safe_remote_get($this->download_url, [
            'timeout' => 60,
            'stream' => true,
            'filename' => $temp_path,
        ]);

        if (is_wp_error($response)) {
            @unlink($temp_path);
            Helpers::log_error(
                'Cannot store file in upload folder',
                'Import',
                ['file' => $filename, 'error' => $response->get_error_message()],
                __LINE__
            );

            return false;
        }

        // 5. A non-200 response body was still written to disk. Check the status code.
        $response_code = (int) wp_remote_retrieve_response_code($response);

        if (200 !== $response_code) {
            @unlink($temp_path);
            Helpers::log_error(
                'Import failed: unexpected response code',
                'Import',
                ['file' => $filename, 'code' => $response_code],
                __LINE__
            );

            return false;
        }

        if (!file_exists($temp_path) || 0 === filesize($temp_path)) {
            @unlink($temp_path);
            Helpers::log_error('Import failed: empty file', 'Import', ['file' => $filename], __LINE__);

            return false;
        }

        // 6. Verify the actual bytes, not just the name. This is what wp_handle_upload() does.
        if (apply_filters('outofthebox_import_verify_file_contents', true, $this->entry)) {
            $checked = wp_check_filetype_and_ext($temp_path, $filename, $allowed_mimes);

            if (empty($checked['type'])) {
                @unlink($temp_path);
                Helpers::log_error(
                    'Import rejected: file contents do not match extension',
                    'Import',
                    ['file' => $filename],
                    __LINE__
                );

                return false;
            }

            // wp_check_filetype_and_ext() can propose a corrected filename (e.g. .jpeg -> .jpg).
            if (!empty($checked['proper_filename'])) {
                $filename = wp_unique_filename($upload_dir['path'], $checked['proper_filename']);
                $target_path = $upload_dir['path'].'/'.$filename;
            }

            $this->validated_file_type = [
                'ext' => (string) ($checked['ext'] ?: $filetype['ext']),
                'type' => (string) $checked['type'],
            ];
        }

        // 7. Move into place only now.
        if (!@rename($temp_path, $target_path)) {
            @unlink($temp_path);
            Helpers::log_error('Cannot move imported file into place', 'Import', ['file' => $target_path], __LINE__);

            return false;
        }

        $perms = defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : (fileperms(dirname($target_path)) & 0000666);
        @chmod($target_path, $perms);

        $this->attachment_name = $filename;
        $this->import_path = $target_path;

        return true;
    }

    /**
     * Insert the downloaded file as an attachment.
     *
     * @return int attachment ID
     */
    public function insert_attachment_to_library()
    {
        $file_path = $this->import_path;

        if (empty($this->validated_file_type['type'])) {
            Helpers::log_error('Import rejected: missing validated file type', 'Import', ['file' => $file_path], __LINE__);

            return false;
        }

        $upload_dir = wp_upload_dir();

        $attachment = [
            'guid' => $upload_dir['url'].'/'.basename($file_path),
            'post_mime_type' => $this->validated_file_type['type'],
            'post_title' => sanitize_title($this->entry->get_basename()),
            'post_content' => \sanitize_text_field($this->entry->get_description()),
            'post_status' => 'inherit',
        ];

        $attach_id = wp_insert_attachment($attachment, $file_path, 0, true);

        if (is_wp_error($attach_id) || $attach_id <= 0) {
            @unlink($file_path);
            Helpers::log_error('Cannot insert imported attachment.', 'Import', ['file' => $file_path], __LINE__);

            return false;
        }

        $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return $attach_id;
    }
}
