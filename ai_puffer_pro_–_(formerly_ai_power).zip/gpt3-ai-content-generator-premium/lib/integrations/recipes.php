<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WPAICG\Core\AIPKit_Event_Registry;
use WPAICG\Lib\Integrations\Apps\AIPKit_App_Connections;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Stored_Recipes
{
    private const OPTION_NAME = 'aipkit_native_app_recipes';

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function get_recipes(): array
    {
        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            return [];
        }

        $recipes = $store['recipes'] ?? [];
        if (!is_array($recipes)) {
            return [];
        }

        $normalized_recipes = array_values(array_filter($recipes, 'is_array'));
        foreach ($normalized_recipes as &$recipe) {
            if (!is_array($recipe)) {
                continue;
            }

            $recipe['template_slug'] = self::normalize_template_slug((string) ($recipe['template_slug'] ?? ''));
            unset($recipe['description']);
        }
        unset($recipe);

        return $normalized_recipes;
    }

    /**
     * @return array<string, string>
     */
    public static function get_event_options(): array
    {
        $definitions = class_exists(AIPKit_Event_Registry::class)
            ? AIPKit_Event_Registry::get_definitions()
            : [];

        $options = [];
        foreach ($definitions as $event_name => $definition) {
            $options[(string) $event_name] = (string) ($definition['label'] ?? $event_name);
        }

        return $options;
    }

    /**
     * @return array<int, string>
     */
    public static function get_chatbot_scope_options(): array
    {
        $admin_setup_class = '\WPAICG\Chat\Admin\AdminSetup';
        if (!class_exists($admin_setup_class)) {
            return [];
        }

        $chatbot_posts = get_posts([
            'post_type' => $admin_setup_class::POST_TYPE,
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'suppress_filters' => false,
        ]);

        if (!is_array($chatbot_posts) || empty($chatbot_posts)) {
            return [];
        }

        $default_bot_id = class_exists('\WPAICG\Chat\Storage\DefaultBotSetup')
            ? (int) \WPAICG\Chat\Storage\DefaultBotSetup::get_default_bot_id()
            : 0;

        usort($chatbot_posts, static function ($left, $right) use ($default_bot_id): int {
            $left_post = $left instanceof \WP_Post ? $left : null;
            $right_post = $right instanceof \WP_Post ? $right : null;
            if (!$left_post || !$right_post) {
                return 0;
            }

            $left_is_default = ((int) $left_post->ID === $default_bot_id);
            $right_is_default = ((int) $right_post->ID === $default_bot_id);
            if ($left_is_default && !$right_is_default) {
                return -1;
            }
            if (!$left_is_default && $right_is_default) {
                return 1;
            }

            return strcmp((string) $left_post->post_title, (string) $right_post->post_title);
        });

        $options = [];
        foreach ($chatbot_posts as $chatbot_post) {
            if (!$chatbot_post instanceof \WP_Post) {
                continue;
            }

            $chatbot_id = (int) $chatbot_post->ID;
            if ($chatbot_id <= 0) {
                continue;
            }

            $chatbot_name = sanitize_text_field((string) $chatbot_post->post_title);
            $options[$chatbot_id] = $chatbot_name !== ''
                ? $chatbot_name
                : sprintf(
                    /* translators: %d: chatbot post ID */
                    __('Chatbot #%d', 'gpt3-ai-content-generator'),
                    $chatbot_id
                );
        }

        return $options;
    }

    /**
     * @return array<int, string>
     */
    public static function get_ai_form_scope_options(): array
    {
        $admin_setup_class = '\WPAICG\AIForms\Admin\AIPKit_AI_Form_Admin_Setup';
        if (!class_exists($admin_setup_class)) {
            return [];
        }

        $form_posts = get_posts([
            'post_type' => $admin_setup_class::POST_TYPE,
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'suppress_filters' => false,
        ]);

        if (!is_array($form_posts) || empty($form_posts)) {
            return [];
        }

        $options = [];
        foreach ($form_posts as $form_post) {
            if (!$form_post instanceof \WP_Post) {
                continue;
            }

            $form_id = (int) $form_post->ID;
            if ($form_id <= 0) {
                continue;
            }

            $form_name = sanitize_text_field((string) $form_post->post_title);
            $options[$form_id] = $form_name !== ''
                ? $form_name
                : sprintf(
                    /* translators: %d: AI Form post ID */
                    __('AI Form #%d', 'gpt3-ai-content-generator'),
                    $form_id
                );
        }

        return $options;
    }

    /**
     * @return array<string, mixed>
     */
    public static function get_chatbot_connected_apps_payload(int $bot_id): array
    {
        return self::get_connected_apps_payload($bot_id, 'chatbot');
    }

    /**
     * @return array<string, mixed>
     */
    public static function get_ai_form_connected_apps_payload(int $form_id): array
    {
        return self::get_connected_apps_payload($form_id, 'ai_form');
    }

    /**
     * @return array<string, mixed>
     */
    private static function get_connected_apps_payload(int $object_id, string $scope): array
    {
        $target_id = absint($object_id);
        if ($target_id <= 0) {
            return [
                'count' => 0,
                'summary' => '',
                'recipes' => [],
            ];
        }

        $is_chatbot = $scope === 'chatbot';
        $id_key = $is_chatbot ? 'bot_ids' : 'form_ids';
        $event_options = self::get_event_options();
        $action_options = self::get_action_options();
        $app_options = class_exists(AIPKit_App_Connections::class)
            ? AIPKit_App_Connections::get_supported_app_options()
            : [];

        $connections_by_id = [];
        if (class_exists(AIPKit_App_Connections::class)) {
            foreach (AIPKit_App_Connections::get_connections() as $connection) {
                if (!is_array($connection)) {
                    continue;
                }

                $connection_id = sanitize_text_field((string) ($connection['id'] ?? ''));
                if ($connection_id === '') {
                    continue;
                }

                $connections_by_id[$connection_id] = $connection;
            }
        }

        $scoped_recipes = [];
        foreach (self::get_recipes() as $recipe) {
            if (!is_array($recipe)) {
                continue;
            }

            $event_name = sanitize_text_field((string) ($recipe['event_name'] ?? ''));
            if ($is_chatbot ? strpos($event_name, 'chatbot.') !== 0 : $event_name !== 'form.submitted') {
                continue;
            }

            $scope_ids = self::get_scope_filter_ids($recipe, $scope, $id_key);
            if (!empty($scope_ids) && !in_array($target_id, $scope_ids, true)) {
                continue;
            }

            $connection_id = sanitize_text_field((string) ($recipe['connection_id'] ?? ''));
            $connection = $connections_by_id[$connection_id] ?? null;
            $validation_state = class_exists(AIPKit_Recipe_Validator::class)
                ? AIPKit_Recipe_Validator::get_recipe_ui_state($recipe, is_array($connection) ? $connection : null)
                : [
                    'status_key' => 'warning',
                    'summary' => __('Validation unavailable.', 'gpt3-ai-content-generator'),
                ];
            $status_key = sanitize_key((string) ($validation_state['status_key'] ?? 'warning'));
            if (!in_array($status_key, ['ready', 'warning', 'error', 'reauth_required'], true)) {
                $status_key = 'warning';
            }

            $app_slug = sanitize_key((string) ($recipe['app_slug'] ?? ''));
            $action_slug = sanitize_key((string) ($recipe['action_slug'] ?? ''));
            $connection_name = is_array($connection)
                ? sanitize_text_field((string) ($connection['name'] ?? ''))
                : '';

            $scoped_recipes[] = [
                'id' => sanitize_text_field((string) ($recipe['id'] ?? '')),
                'name' => sanitize_text_field((string) ($recipe['name'] ?? __('Untitled recipe', 'gpt3-ai-content-generator'))),
                'app_slug' => $app_slug,
                'app_label' => sanitize_text_field((string) ($app_options[$app_slug] ?? ucfirst($app_slug))),
                'connection_label' => $connection_name !== ''
                    ? $connection_name
                    : __('No connection', 'gpt3-ai-content-generator'),
                'event_name' => $event_name,
                'event_label' => sanitize_text_field((string) ($event_options[$event_name] ?? $event_name)),
                'action_label' => sanitize_text_field((string) ($action_options[$action_slug] ?? $action_slug)),
                'status_key' => $status_key,
                'status_label' => self::get_recipe_ui_status_label($status_key),
                'validation_summary' => sanitize_text_field((string) ($validation_state['summary'] ?? '')),
                'is_enabled' => !empty($recipe['is_enabled']),
                'scope_label' => $is_chatbot
                    ? self::get_chatbot_recipe_scope_label($scope_ids, $target_id)
                    : self::get_ai_form_recipe_scope_label($scope_ids, $target_id),
                // Whether it covers every record, only this one, or several chosen ones.
                'scope_key' => empty($scope_ids) ? 'all' : ((count($scope_ids) === 1 && (int) $scope_ids[0] === $target_id) ? 'this' : 'selected'),
            ];
        }

        $count = count($scoped_recipes);
        // The apps that get these chats, by name, such as "2 apps: Slack, HubSpot".
        $app_names = array_keys(array_filter(array_column($scoped_recipes, 'app_label', 'app_label')));

        return [
            'count' => $count,
            'summary' => $count > 0
                ? sprintf(
                    /* translators: %d: number of recipes. */
                    _n('%d recipe', '%d recipes', $count, 'gpt3-ai-content-generator'),
                    $count
                )
                : '',
            'apps_summary' => $app_names
                ? sprintf(
                    /* translators: 1: number of apps, 2: their names, such as Slack, HubSpot. */
                    _n('%1$d app: %2$s', '%1$d apps: %2$s', count($app_names), 'gpt3-ai-content-generator'),
                    count($app_names),
                    implode(', ', $app_names)
                )
                : '',
            'recipes' => $scoped_recipes,
        ];
    }

    /**
     * @return array<string, string>
     */
    public static function get_action_options(): array
    {
        return [
            'slack_message_create' => __('Slack message', 'gpt3-ai-content-generator'),
            'hubspot_contact_upsert' => __('HubSpot contact', 'gpt3-ai-content-generator'),
            'notion_page_create' => __('Notion page', 'gpt3-ai-content-generator'),
            'notion_database_item_create' => __('Notion database item', 'gpt3-ai-content-generator'),
            'pipedrive_person_upsert' => __('Pipedrive person', 'gpt3-ai-content-generator'),
            'zapier_webhook_trigger' => __('Zapier webhook', 'gpt3-ai-content-generator'),
            'make_webhook_trigger' => __('Make webhook', 'gpt3-ai-content-generator'),
            'n8n_webhook_trigger' => __('n8n webhook', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @return array<string, array<int, string>>
     */
    public static function get_action_options_by_app(): array
    {
        return [
            'slack' => ['slack_message_create'],
            'hubspot' => ['hubspot_contact_upsert'],
            'notion' => ['notion_page_create', 'notion_database_item_create'],
            'pipedrive' => ['pipedrive_person_upsert'],
            'zapier' => ['zapier_webhook_trigger'],
            'make' => ['make_webhook_trigger'],
            'n8n' => ['n8n_webhook_trigger'],
        ];
    }

    public static function get_default_action_for_app(string $app_slug): string
    {
        $app_key = sanitize_key($app_slug);
        $actions_by_app = self::get_action_options_by_app();
        $app_actions = $actions_by_app[$app_key] ?? [];

        if (!empty($app_actions)) {
            return (string) $app_actions[0];
        }

        $all_actions = array_keys(self::get_action_options());
        return (string) ($all_actions[0] ?? '');
    }

    /**
     * @return array<string, array<string, string>>
     */
    public static function get_mapping_event_object_types(): array
    {
        return [
            'chatbot.session_started' => [
                'type' => 'conversation',
                'label' => __('Conversation record', 'gpt3-ai-content-generator'),
            ],
            'chatbot.user_message_submitted' => [
                'type' => 'message',
                'label' => __('Message record', 'gpt3-ai-content-generator'),
            ],
            'chatbot.response_generated' => [
                'type' => 'response',
                'label' => __('Response record', 'gpt3-ai-content-generator'),
            ],
            'chatbot.fb_submitted' => [
                'type' => 'feedback',
                'label' => __('Feedback record', 'gpt3-ai-content-generator'),
            ],
            'chatbot.form_submitted' => [
                'type' => 'submission',
                'label' => __('Chatbot form submission record', 'gpt3-ai-content-generator'),
            ],
            'content.generated' => [
                'type' => 'content',
                'label' => __('Content record', 'gpt3-ai-content-generator'),
            ],
            'task.item_completed' => [
                'type' => 'content',
                'label' => __('Content record', 'gpt3-ai-content-generator'),
            ],
            'form.submitted' => [
                'type' => 'submission',
                'label' => __('Submission record', 'gpt3-ai-content-generator'),
            ],
            'image.generated' => [
                'type' => 'asset',
                'label' => __('Asset record', 'gpt3-ai-content-generator'),
            ],
            'kb.source_indexed' => [
                'type' => 'content',
                'label' => __('Content record', 'gpt3-ai-content-generator'),
            ],
        ];
    }

    /**
     * @return array<string, array<string, string>>
     */
    public static function get_mapping_source_options_by_event(): array
    {
        $ai_form_input_options = self::get_ai_form_dynamic_input_source_options();

        return [
            'chatbot.session_started' => [
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.bot.id' => __('Chatbot ID', 'gpt3-ai-content-generator'),
                'data.bot.name' => __('Chatbot name', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.conversation.message_count' => __('Message count', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
                'data.message.id' => __('Message ID', 'gpt3-ai-content-generator'),
                'data.message.text' => __('User message', 'gpt3-ai-content-generator'),
            ],
            'chatbot.user_message_submitted' => [
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.bot.id' => __('Chatbot ID', 'gpt3-ai-content-generator'),
                'data.bot.name' => __('Chatbot name', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.conversation.message_count' => __('Message count', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
                'data.message.id' => __('Message ID', 'gpt3-ai-content-generator'),
                'data.message.text' => __('User message', 'gpt3-ai-content-generator'),
            ],
            'chatbot.response_generated' => [
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.bot.id' => __('Chatbot ID', 'gpt3-ai-content-generator'),
                'data.bot.name' => __('Chatbot name', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.conversation.message_count' => __('Message count', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
                'data.user_message.id' => __('User Message ID', 'gpt3-ai-content-generator'),
                'data.user_message.text' => __('User message', 'gpt3-ai-content-generator'),
                'data.response.id' => __('Response ID', 'gpt3-ai-content-generator'),
                'data.response.text' => __('Bot response', 'gpt3-ai-content-generator'),
            ],
            'chatbot.fb_submitted' => [
                'data.feedback' => __('Feedback', 'gpt3-ai-content-generator'),
                'data.bot.id' => __('Chatbot ID', 'gpt3-ai-content-generator'),
                'data.bot.name' => __('Chatbot name', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.message.id' => __('Message ID', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
            ],
            'chatbot.form_submitted' => [
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.bot.id' => __('Chatbot ID', 'gpt3-ai-content-generator'),
                'data.bot.name' => __('Chatbot name', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.conversation.message_count' => __('Message count', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
                'data.form.id' => __('Form ID', 'gpt3-ai-content-generator'),
                'data.form.name' => __('Form name', 'gpt3-ai-content-generator'),
                'data.submission.id' => __('Submission ID', 'gpt3-ai-content-generator'),
                'data.summary' => __('Submission summary', 'gpt3-ai-content-generator'),
                'data.inputs' => __('All submitted inputs', 'gpt3-ai-content-generator'),
                'data.inputs.email' => __('Email', 'gpt3-ai-content-generator'),
                'data.inputs.name' => __('Name', 'gpt3-ai-content-generator'),
                'data.inputs.first_name' => __('First name', 'gpt3-ai-content-generator'),
                'data.inputs.last_name' => __('Last name', 'gpt3-ai-content-generator'),
                'data.inputs.phone' => __('Phone', 'gpt3-ai-content-generator'),
                'data.inputs.company' => __('Company', 'gpt3-ai-content-generator'),
                'data.inputs.message' => __('Message', 'gpt3-ai-content-generator'),
                'data.display_values' => __('Submitted display values', 'gpt3-ai-content-generator'),
                'data.labels' => __('Submitted field labels', 'gpt3-ai-content-generator'),
                'data.page.id' => __('Page ID', 'gpt3-ai-content-generator'),
                'data.page.url' => __('Page URL', 'gpt3-ai-content-generator'),
            ],
            'content.generated' => [
                'data.title' => __('Title', 'gpt3-ai-content-generator'),
                'data.content' => __('Content', 'gpt3-ai-content-generator'),
                'data.excerpt' => __('Excerpt', 'gpt3-ai-content-generator'),
                'data.meta_description' => __('Meta description', 'gpt3-ai-content-generator'),
                'data.focus_keyword' => __('Focus keyword', 'gpt3-ai-content-generator'),
                'data.tags' => __('Tags', 'gpt3-ai-content-generator'),
                'data.post.id' => __('Post ID', 'gpt3-ai-content-generator'),
                'data.post.status' => __('Post status', 'gpt3-ai-content-generator'),
                'data.post.url' => __('Post URL', 'gpt3-ai-content-generator'),
                'data.conversation.id' => __('Conversation ID', 'gpt3-ai-content-generator'),
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.input.keywords' => __('Keywords', 'gpt3-ai-content-generator'),
                'data.input.source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'data.task.id' => __('Task ID', 'gpt3-ai-content-generator'),
                'data.task.queue_item_id' => __('Queue Item ID', 'gpt3-ai-content-generator'),
            ],
            'task.item_completed' => [
                'data.task.id' => __('Task ID', 'gpt3-ai-content-generator'),
                'data.task.name' => __('Task name', 'gpt3-ai-content-generator'),
                'data.task.type' => __('Task type', 'gpt3-ai-content-generator'),
                'data.queue_item.id' => __('Queue item ID', 'gpt3-ai-content-generator'),
                'data.queue_item.target_identifier' => __('Target identifier', 'gpt3-ai-content-generator'),
                'data.queue_item.status' => __('Queue status', 'gpt3-ai-content-generator'),
                'data.queue_item.attempts' => __('Attempts', 'gpt3-ai-content-generator'),
                'data.result.message' => __('Result message', 'gpt3-ai-content-generator'),
                'data.result.generated_post_id' => __('Generated post ID', 'gpt3-ai-content-generator'),
                'data.item.content_title' => __('Content title', 'gpt3-ai-content-generator'),
                'data.item.post_id' => __('Post ID', 'gpt3-ai-content-generator'),
                'data.item.content_keywords' => __('Content keywords', 'gpt3-ai-content-generator'),
                'data.item.generation_mode' => __('Generation mode', 'gpt3-ai-content-generator'),
            ],
            'form.submitted' => [
                'data.form.id' => __('Form ID', 'gpt3-ai-content-generator'),
                'data.form.name' => __('Form name', 'gpt3-ai-content-generator'),
                'data.submission.id' => __('Submission ID', 'gpt3-ai-content-generator'),
                'data.submission.count' => __('Submission count', 'gpt3-ai-content-generator'),
                'data.actor.type' => __('Actor type', 'gpt3-ai-content-generator'),
                'data.actor.user_id' => __('User ID', 'gpt3-ai-content-generator'),
                'data.ai.provider' => __('AI provider', 'gpt3-ai-content-generator'),
                'data.ai.model' => __('AI model', 'gpt3-ai-content-generator'),
                'data.response.text' => __('AI response', 'gpt3-ai-content-generator'),
                'data.inputs' => __('All submitted inputs', 'gpt3-ai-content-generator'),
            ] + $ai_form_input_options,
            'image.generated' => [
                'data.prompt' => __('Prompt', 'gpt3-ai-content-generator'),
                'data.provider' => __('Provider', 'gpt3-ai-content-generator'),
                'data.model' => __('Model', 'gpt3-ai-content-generator'),
                'data.mode' => __('Mode', 'gpt3-ai-content-generator'),
                'data.media_type' => __('Media type', 'gpt3-ai-content-generator'),
                'data.output_count' => __('Output count', 'gpt3-ai-content-generator'),
                'data.outputs.images.0.url' => __('First image URL', 'gpt3-ai-content-generator'),
                'data.outputs.images.0.media_library_url' => __('First media library URL', 'gpt3-ai-content-generator'),
                'data.outputs.images.0.attachment_id' => __('First attachment ID', 'gpt3-ai-content-generator'),
                'data.outputs.videos.0.url' => __('First video URL', 'gpt3-ai-content-generator'),
            ],
            'kb.source_indexed' => [
                'data.source.log_id' => __('Log ID', 'gpt3-ai-content-generator'),
                'data.source.post_id' => __('Post ID', 'gpt3-ai-content-generator'),
                'data.source.post_title' => __('Post title', 'gpt3-ai-content-generator'),
                'data.source.post_url' => __('Post URL', 'gpt3-ai-content-generator'),
                'data.provider' => __('Provider', 'gpt3-ai-content-generator'),
                'data.store.id' => __('Store ID', 'gpt3-ai-content-generator'),
                'data.store.name' => __('Store name', 'gpt3-ai-content-generator'),
                'data.message' => __('Message', 'gpt3-ai-content-generator'),
                'data.embedding.provider' => __('Embedding provider', 'gpt3-ai-content-generator'),
                'data.embedding.model' => __('Embedding model', 'gpt3-ai-content-generator'),
            ],
        ];
    }

    /**
     * @return array<string, array<string, string>>
     */
    public static function get_mapping_target_options_by_action(): array
    {
        return [
            'slack_message_create' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'body' => __('Body', 'gpt3-ai-content-generator'),
                'channel' => __('Channel override', 'gpt3-ai-content-generator'),
                'username' => __('Username', 'gpt3-ai-content-generator'),
                'icon_emoji' => __('Icon emoji', 'gpt3-ai-content-generator'),
            ],
            'hubspot_contact_upsert' => [
                'email' => __('Email', 'gpt3-ai-content-generator'),
                'firstname' => __('First name', 'gpt3-ai-content-generator'),
                'lastname' => __('Last name', 'gpt3-ai-content-generator'),
                'phone' => __('Phone', 'gpt3-ai-content-generator'),
                'company' => __('Company', 'gpt3-ai-content-generator'),
                'jobtitle' => __('Job title', 'gpt3-ai-content-generator'),
                'website' => __('Website', 'gpt3-ai-content-generator'),
            ],
            'notion_page_create' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'content' => __('Content', 'gpt3-ai-content-generator'),
                'excerpt' => __('Excerpt', 'gpt3-ai-content-generator'),
                'summary' => __('Summary', 'gpt3-ai-content-generator'),
                'source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'status' => __('Status', 'gpt3-ai-content-generator'),
            ],
            'notion_database_item_create' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'summary' => __('Summary', 'gpt3-ai-content-generator'),
                'feedback' => __('Feedback', 'gpt3-ai-content-generator'),
                'status' => __('Status', 'gpt3-ai-content-generator'),
                'asset_url' => __('Asset URL', 'gpt3-ai-content-generator'),
                'source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'bot_name' => __('Bot name', 'gpt3-ai-content-generator'),
                'tags' => __('Tags', 'gpt3-ai-content-generator'),
            ],
            'pipedrive_person_upsert' => [
                'name' => __('Name', 'gpt3-ai-content-generator'),
                'email' => __('Email', 'gpt3-ai-content-generator'),
                'phone' => __('Phone', 'gpt3-ai-content-generator'),
                'org_name' => __('Organization', 'gpt3-ai-content-generator'),
            ],
            'zapier_webhook_trigger' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'body' => __('Body', 'gpt3-ai-content-generator'),
                'source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'payload_json' => __('Payload JSON', 'gpt3-ai-content-generator'),
            ],
            'make_webhook_trigger' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'body' => __('Body', 'gpt3-ai-content-generator'),
                'source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'payload_json' => __('Payload JSON', 'gpt3-ai-content-generator'),
            ],
            'n8n_webhook_trigger' => [
                'title' => __('Title', 'gpt3-ai-content-generator'),
                'body' => __('Body', 'gpt3-ai-content-generator'),
                'source_url' => __('Source URL', 'gpt3-ai-content-generator'),
                'payload_json' => __('Payload JSON', 'gpt3-ai-content-generator'),
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    public static function get_mapping_transform_options(): array
    {
        return [
            '' => __('No transform', 'gpt3-ai-content-generator'),
            'json_encode' => __('JSON encode', 'gpt3-ai-content-generator'),
            'join_lines' => __('Join with line breaks', 'gpt3-ai-content-generator'),
            'yes_no' => __('Yes / no', 'gpt3-ai-content-generator'),
            'lowercase' => __('Lowercase', 'gpt3-ai-content-generator'),
            'uppercase' => __('Uppercase', 'gpt3-ai-content-generator'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function get_mapping_ui_definitions(): array
    {
        return [
            'event_object_types' => self::get_mapping_event_object_types(),
            'source_options_by_event' => self::get_mapping_source_options_by_event(),
            'source_groups_by_event' => self::get_mapping_source_groups_by_event(),
            'target_options_by_action' => self::get_mapping_target_options_by_action(),
            'transform_options' => self::get_mapping_transform_options(),
        ];
    }

    /**
     * @return array<string, array<int, array<string, mixed>>>
     */
    private static function get_mapping_source_groups_by_event(): array
    {
        $source_options_by_event = self::get_mapping_source_options_by_event();
        $ai_form_input_groups = self::get_ai_form_dynamic_input_source_groups();

        $grouped_sources = [];
        foreach ($source_options_by_event as $event_name => $source_options) {
            if (!is_array($source_options)) {
                continue;
            }

            $chatbot_event_groups = self::get_chatbot_source_groups_for_event((string) $event_name, $source_options);
            if (!empty($chatbot_event_groups)) {
                $grouped_sources[(string) $event_name] = $chatbot_event_groups;
                continue;
            }

            $core_options = $source_options;
            if ($event_name === 'form.submitted' && !empty($ai_form_input_groups)) {
                foreach ($ai_form_input_groups as $form_group) {
                    if (!is_array($form_group) || empty($form_group['options']) || !is_array($form_group['options'])) {
                        continue;
                    }

                    foreach (array_keys($form_group['options']) as $source_path) {
                        unset($core_options[$source_path]);
                    }
                }
            }

            $event_groups = [];
            if (!empty($core_options)) {
                $event_groups[] = [
                    'label' => __('Core sources', 'gpt3-ai-content-generator'),
                    'options' => $core_options,
                ];
            }

            if ($event_name === 'form.submitted' && !empty($ai_form_input_groups)) {
                foreach ($ai_form_input_groups as $form_group) {
                    if (!is_array($form_group) || empty($form_group['options']) || !is_array($form_group['options'])) {
                        continue;
                    }

                    $event_groups[] = [
                        'label' => sanitize_text_field((string) ($form_group['label'] ?? __('AI form inputs', 'gpt3-ai-content-generator'))),
                        'options' => $form_group['options'],
                    ];
                }
            }

            $grouped_sources[(string) $event_name] = $event_groups;
        }

        return $grouped_sources;
    }

    /**
     * @param array<string, string> $source_options
     * @return array<int, array<string, mixed>>
     */
    private static function get_chatbot_source_groups_for_event(string $event_name, array $source_options): array
    {
        $group_paths_by_event = [
            'chatbot.session_started' => [
                __('Core sources', 'gpt3-ai-content-generator') => ['data.ai.provider', 'data.ai.model'],
                __('Chatbot', 'gpt3-ai-content-generator') => ['data.bot.id', 'data.bot.name'],
                __('Conversation', 'gpt3-ai-content-generator') => ['data.conversation.id', 'data.conversation.message_count'],
                __('Actor', 'gpt3-ai-content-generator') => ['data.actor.type', 'data.actor.user_id'],
                __('User Message', 'gpt3-ai-content-generator') => ['data.message.id', 'data.message.text'],
            ],
            'chatbot.user_message_submitted' => [
                __('Core sources', 'gpt3-ai-content-generator') => ['data.ai.provider', 'data.ai.model'],
                __('Chatbot', 'gpt3-ai-content-generator') => ['data.bot.id', 'data.bot.name'],
                __('Conversation', 'gpt3-ai-content-generator') => ['data.conversation.id', 'data.conversation.message_count'],
                __('Actor', 'gpt3-ai-content-generator') => ['data.actor.type', 'data.actor.user_id'],
                __('User Message', 'gpt3-ai-content-generator') => ['data.message.id', 'data.message.text'],
            ],
            'chatbot.response_generated' => [
                __('Core sources', 'gpt3-ai-content-generator') => ['data.ai.provider', 'data.ai.model'],
                __('Chatbot', 'gpt3-ai-content-generator') => ['data.bot.id', 'data.bot.name'],
                __('Conversation', 'gpt3-ai-content-generator') => ['data.conversation.id', 'data.conversation.message_count'],
                __('Actor', 'gpt3-ai-content-generator') => ['data.actor.type', 'data.actor.user_id'],
                __('User Message', 'gpt3-ai-content-generator') => ['data.user_message.id', 'data.user_message.text'],
                __('Bot Response', 'gpt3-ai-content-generator') => ['data.response.id', 'data.response.text'],
            ],
            'chatbot.fb_submitted' => [
                __('Core sources', 'gpt3-ai-content-generator') => ['data.feedback'],
                __('Chatbot', 'gpt3-ai-content-generator') => ['data.bot.id', 'data.bot.name'],
                __('Conversation', 'gpt3-ai-content-generator') => ['data.conversation.id'],
                __('Message', 'gpt3-ai-content-generator') => ['data.message.id'],
                __('Actor', 'gpt3-ai-content-generator') => ['data.actor.type', 'data.actor.user_id'],
            ],
            'chatbot.form_submitted' => [
                __('Core sources', 'gpt3-ai-content-generator') => ['data.ai.provider', 'data.ai.model', 'data.summary'],
                __('Chatbot', 'gpt3-ai-content-generator') => ['data.bot.id', 'data.bot.name'],
                __('Conversation', 'gpt3-ai-content-generator') => ['data.conversation.id', 'data.conversation.message_count'],
                __('Actor', 'gpt3-ai-content-generator') => ['data.actor.type', 'data.actor.user_id'],
                __('Form', 'gpt3-ai-content-generator') => ['data.form.id', 'data.form.name', 'data.submission.id'],
                __('Submitted Inputs', 'gpt3-ai-content-generator') => ['data.inputs', 'data.inputs.email', 'data.inputs.name', 'data.inputs.first_name', 'data.inputs.last_name', 'data.inputs.phone', 'data.inputs.company', 'data.inputs.message', 'data.display_values', 'data.labels'],
                __('Page', 'gpt3-ai-content-generator') => ['data.page.id', 'data.page.url'],
            ],
        ];

        $group_paths = $group_paths_by_event[$event_name] ?? [];
        if (empty($group_paths)) {
            return [];
        }

        $event_groups = [];
        foreach ($group_paths as $group_label => $group_paths_list) {
            $group_options = [];
            foreach ($group_paths_list as $source_path) {
                if (!isset($source_options[$source_path])) {
                    continue;
                }

                $group_options[$source_path] = $source_options[$source_path];
            }

            if (!empty($group_options)) {
                $event_groups[] = [
                    'label' => $group_label,
                    'options' => $group_options,
                ];
            }
        }

        return $event_groups;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function get_ai_form_dynamic_input_source_groups(): array
    {
        $admin_setup_class = '\WPAICG\AIForms\Admin\AIPKit_AI_Form_Admin_Setup';
        if (!class_exists($admin_setup_class)) {
            return [];
        }

        $post_type = $admin_setup_class::POST_TYPE;
        $form_ids = get_posts([
            'post_type' => $post_type,
            'post_status' => ['publish', 'draft'],
            'fields' => 'ids',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'suppress_filters' => false,
        ]);

        if (!is_array($form_ids) || empty($form_ids)) {
            return [];
        }

        $groups = [];
        $used_source_paths = [];
        foreach ($form_ids as $form_id) {
            $structure_json = get_post_meta((int) $form_id, '_aipkit_ai_form_structure', true);
            if (!is_string($structure_json) || $structure_json === '') {
                continue;
            }

            $structure = json_decode($structure_json, true);
            if (!is_array($structure) || empty($structure)) {
                continue;
            }

            $form_options = [];
            self::collect_ai_form_input_source_options($structure, $form_options);
            if (empty($form_options)) {
                continue;
            }

            foreach (array_keys($form_options) as $source_path) {
                if (isset($used_source_paths[$source_path])) {
                    unset($form_options[$source_path]);
                    continue;
                }

                $used_source_paths[$source_path] = true;
            }

            if (empty($form_options)) {
                continue;
            }

            $form_title = get_the_title((int) $form_id);
            $groups[] = [
                'label' => sanitize_text_field($form_title !== '' ? $form_title : sprintf(
                    /* translators: %d: AI Form post ID */
                    __('AI Form #%d', 'gpt3-ai-content-generator'),
                    (int) $form_id
                )),
                'options' => $form_options,
            ];
        }

        return $groups;
    }

    /**
     * @return array<string, string>
     */
    private static function get_ai_form_dynamic_input_source_options(): array
    {
        $groups = self::get_ai_form_dynamic_input_source_groups();
        $options = [];
        foreach ($groups as $group) {
            if (!is_array($group) || empty($group['options']) || !is_array($group['options'])) {
                continue;
            }

            foreach ($group['options'] as $source_path => $source_label) {
                $options[(string) $source_path] = (string) $source_label;
            }
        }

        return $options;
    }

    /**
     * @param array<int, mixed> $structure
     * @param array<string, string> $options
     * @return void
     */
    private static function collect_ai_form_input_source_options(array $structure, array &$options): void
    {
        foreach ($structure as $node) {
            if (!is_array($node)) {
                continue;
            }

            if (($node['type'] ?? '') === 'layout-row' && isset($node['columns']) && is_array($node['columns'])) {
                foreach ($node['columns'] as $column) {
                    if (!is_array($column) || !isset($column['elements']) || !is_array($column['elements'])) {
                        continue;
                    }

                    self::collect_ai_form_input_source_options($column['elements'], $options);
                }
                continue;
            }

            $field_id = sanitize_key((string) ($node['fieldId'] ?? ''));
            if ($field_id === '') {
                continue;
            }

            $label = sanitize_text_field((string) ($node['label'] ?? $field_id));
            $source_path = 'data.inputs.' . $field_id;
            if (!isset($options[$source_path])) {
                $options[$source_path] = sprintf(
                    /* translators: %s: AI Form field label */
                    __('Input: %s', 'gpt3-ai-content-generator'),
                    $label !== '' ? $label : $field_id
                );
            }
        }
    }

    /**
     * @return array<string, array<string, string>>
     */
    public static function get_template_definitions(): array
    {
        $aipkit_translate_labels = true;
        $templates = class_exists(AIPKit_Recipe_Registry::class)
            ? (new AIPKit_Recipe_Registry())->get_templates()
            : (require __DIR__ . '/recipe-templates.php');

        $event_options = self::get_event_options();
        $action_options = self::get_action_options();
        $filtered_templates = [];

        foreach ($templates as $template) {
            if (!is_array($template)) {
                continue;
            }

            $template_slug = self::normalize_template_slug((string) ($template['template_slug'] ?? ''));
            if ($template_slug === '') {
                continue;
            }

            $event_name = sanitize_text_field((string) ($template['event_name'] ?? ''));
            $action_slug = sanitize_key((string) ($template['action_slug'] ?? ''));
            if (!isset($event_options[$event_name]) || !isset($action_options[$action_slug])) {
                continue;
            }

            $template_label = sanitize_text_field((string) ($template['label'] ?? $template_slug));
            $filtered_templates[$template_slug] = [
                'label' => $template_label,
                'name' => sanitize_text_field((string) ($template['name'] ?? $template_label)),
                'app_slug' => sanitize_key((string) ($template['app_slug'] ?? '')),
                'event_name' => $event_name,
                'action_slug' => $action_slug,
                'template_slug' => $template_slug,
                'default_mapping' => self::sanitize_mapping(
                    isset($template['default_mapping']) && is_array($template['default_mapping']) ? $template['default_mapping'] : [],
                    []
                ),
            ];
        }

        return $filtered_templates;
    }

    /**
     * @return array<string, string>
     */
    public static function get_template_options(): array
    {
        $options = [];
        foreach (self::get_template_definitions() as $template_slug => $template) {
            $options[(string) $template_slug] = (string) ($template['label'] ?? $template_slug);
        }

        return $options;
    }

    /**
     * @return array<string, string>|null
     */
    public static function get_template_definition(string $template_slug): ?array
    {
        $template_key = self::normalize_template_slug($template_slug);
        if ($template_key === '') {
            return null;
        }

        $definitions = self::get_template_definitions();
        return isset($definitions[$template_key]) ? $definitions[$template_key] : null;
    }

    /**
     * @param array<int|string, mixed> $raw_recipes
     */
    public static function save_recipes(array $raw_recipes, int $current_user_id = 0): void
    {
        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            $store = [];
        }

        $existing_recipes = self::get_recipes_indexed_by_id();
        $sanitized_recipes = [];

        foreach ($raw_recipes as $raw_recipe) {
            if (!is_array($raw_recipe)) {
                continue;
            }

            $sanitized_recipe = self::sanitize_recipe(
                $raw_recipe,
                $existing_recipes,
                $current_user_id
            );

            if ($sanitized_recipe === null) {
                continue;
            }

            $sanitized_recipes[] = $sanitized_recipe;
        }

        $store['recipes'] = $sanitized_recipes;
        update_option(self::OPTION_NAME, $store, 'no');
    }

    /**
     * Reports recipe subscribers to the shared event delivery policy.
     *
     * Subscriber detection is independent of execution gates, as it was before
     * recipe lookup moved out of the shared runtime.
     */
    public static function has_event_delivery_subscribers(bool $has_subscribers, string $event_name): bool
    {
        return $has_subscribers || !empty(self::get_matching_enabled_recipes($event_name));
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function get_matching_enabled_recipes(string $event_name): array
    {
        $normalized_event_name = sanitize_text_field($event_name);
        if ($normalized_event_name === '') {
            return [];
        }

        return array_values(array_filter(self::get_recipes(), static function ($recipe) use ($normalized_event_name): bool {
            if (!is_array($recipe)) {
                return false;
            }

            if (sanitize_text_field((string) ($recipe['event_name'] ?? '')) !== $normalized_event_name) {
                return false;
            }

            if (empty($recipe['is_enabled'])) {
                return false;
            }

            return sanitize_text_field((string) ($recipe['connection_id'] ?? '')) !== '';
        }));
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function get_recipe_by_id(string $recipe_id): ?array
    {
        $recipe_key = sanitize_text_field($recipe_id);
        if ($recipe_key === '') {
            return null;
        }

        $indexed = self::get_recipes_indexed_by_id();

        return isset($indexed[$recipe_key]) && is_array($indexed[$recipe_key])
            ? $indexed[$recipe_key]
            : null;
    }

    /**
     * @param array<string, mixed> $updates
     */
    public static function update_recipe_runtime_state(string $recipe_id, array $updates, int $current_user_id = 0): bool
    {
        $recipe_key = sanitize_text_field($recipe_id);
        if ($recipe_key === '') {
            return false;
        }

        $store = get_option(self::OPTION_NAME, []);
        if (!is_array($store)) {
            return false;
        }

        $recipes = $store['recipes'] ?? [];
        if (!is_array($recipes)) {
            return false;
        }

        $updated = false;
        foreach ($recipes as $index => $recipe) {
            if (!is_array($recipe)) {
                continue;
            }

            $current_id = sanitize_text_field((string) ($recipe['id'] ?? ''));
            if ($current_id !== $recipe_key) {
                continue;
            }

            if (isset($updates['status'])) {
                $status = sanitize_key((string) $updates['status']);
                if (in_array($status, ['draft', 'active', 'inactive', 'error'], true)) {
                    $recipe['status'] = $status;
                }
            }

            if (isset($updates['last_delivery_at'])) {
                $recipe['last_delivery_at'] = sanitize_text_field((string) $updates['last_delivery_at']);
            }

            $recipe['updated_by'] = $current_user_id ?: null;
            $recipe['updated_at'] = gmdate('c');
            $recipes[$index] = $recipe;
            $updated = true;
            break;
        }

        if (!$updated) {
            return false;
        }

        $store['recipes'] = array_values($recipes);
        update_option(self::OPTION_NAME, $store, 'no');

        return true;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private static function get_recipes_indexed_by_id(): array
    {
        $indexed = [];
        foreach (self::get_recipes() as $recipe) {
            $recipe_id = sanitize_text_field((string) ($recipe['id'] ?? ''));
            if ($recipe_id === '') {
                continue;
            }

            $indexed[$recipe_id] = $recipe;
        }

        return $indexed;
    }

    /**
     * @param array<string, mixed> $raw_recipe
     * @param array<string, array<string, mixed>> $existing_recipes
     * @return array<string, mixed>|null
     */
    private static function sanitize_recipe(
        array $raw_recipe,
        array $existing_recipes,
        int $current_user_id = 0
    ): ?array {
        $event_options = self::get_event_options();
        $action_options = self::get_action_options();

        $recipe_id = sanitize_text_field((string) ($raw_recipe['id'] ?? ''));
        if ($recipe_id === '') {
            $recipe_id = wp_generate_uuid4();
        }

        $existing_recipe = $existing_recipes[$recipe_id] ?? [];

        $app_slug = sanitize_key((string) ($raw_recipe['app_slug'] ?? 'slack'));
        $connection_id = sanitize_text_field((string) ($raw_recipe['connection_id'] ?? ''));
        $event_name = sanitize_text_field((string) ($raw_recipe['event_name'] ?? ''));
        if (!isset($event_options[$event_name])) {
            $event_name = (string) array_key_first($event_options);
        }

        $action_slug = sanitize_key((string) ($raw_recipe['action_slug'] ?? ''));
        if (!isset($action_options[$action_slug])) {
            $action_slug = self::get_default_action_for_app($app_slug);
        }

        $name = sanitize_text_field((string) ($raw_recipe['name'] ?? ''));
        if ($name === '') {
            $name = __('Untitled recipe', 'gpt3-ai-content-generator');
        }

        $status = sanitize_key((string) ($raw_recipe['status'] ?? ($existing_recipe['status'] ?? 'draft')));
        if (!in_array($status, ['draft', 'active', 'inactive', 'error'], true)) {
            $status = 'draft';
        }

        $is_enabled = isset($raw_recipe['is_enabled']) && (string) ($raw_recipe['is_enabled']) === '1';
        if ($is_enabled && $status === 'inactive') {
            $status = 'active';
        } elseif (!$is_enabled && $status === 'active') {
            $status = 'inactive';
        }

        $created_at = sanitize_text_field((string) ($existing_recipe['created_at'] ?? gmdate('c')));
        $created_by = isset($existing_recipe['created_by']) ? (int) $existing_recipe['created_by'] : ($current_user_id ?: null);

        $template_slug = self::normalize_template_slug((string) ($raw_recipe['template_slug'] ?? ($existing_recipe['template_slug'] ?? '')));
        if (self::get_template_definition($template_slug) === null) {
            $template_slug = '';
        }

        $mapping = self::sanitize_mapping(
            isset($raw_recipe['mapping']) && is_array($raw_recipe['mapping']) ? $raw_recipe['mapping'] : [],
            isset($existing_recipe['mapping']) && is_array($existing_recipe['mapping']) ? $existing_recipe['mapping'] : []
        );
        $filters = self::sanitize_filters(
            isset($raw_recipe['filters']) && is_array($raw_recipe['filters']) ? $raw_recipe['filters'] : [],
            isset($existing_recipe['filters']) && is_array($existing_recipe['filters']) ? $existing_recipe['filters'] : [],
            $event_name
        );

        return [
            'id' => $recipe_id,
            'name' => $name,
            'connection_id' => $connection_id,
            'app_slug' => $app_slug,
            'event_name' => $event_name,
            'action_slug' => $action_slug,
            'template_slug' => $template_slug,
            'status' => $status,
            'is_enabled' => $is_enabled,
            'filters' => $filters,
            'mapping' => $mapping,
            'last_delivery_at' => sanitize_text_field((string) ($existing_recipe['last_delivery_at'] ?? '')),
            'created_by' => $created_by,
            'updated_by' => $current_user_id ?: null,
            'created_at' => $created_at,
            'updated_at' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $raw_mapping
     * @param array<string, mixed> $existing_mapping
     * @return array<string, mixed>
     */
    private static function sanitize_mapping(array $raw_mapping, array $existing_mapping = []): array
    {
        $raw_fields = isset($raw_mapping['fields']) && is_array($raw_mapping['fields'])
            ? $raw_mapping['fields']
            : [];

        $transform_options = self::get_mapping_transform_options();
        $sanitized_fields = [];

        foreach ($raw_fields as $raw_field) {
            if (!is_array($raw_field)) {
                continue;
            }

            $target_field = sanitize_key((string) ($raw_field['target_field'] ?? ''));
            $source_path = sanitize_text_field((string) ($raw_field['source_path'] ?? ''));

            if ($target_field === '' || $source_path === '') {
                continue;
            }

            $transform = sanitize_key((string) ($raw_field['transform'] ?? ''));
            if (!array_key_exists($transform, $transform_options)) {
                $transform = '';
            }

            $fallback_value_raw = $raw_field['fallback_value'] ?? '';
            if (is_bool($fallback_value_raw)) {
                $fallback_value = $fallback_value_raw;
            } elseif (is_numeric($fallback_value_raw) && !is_string($fallback_value_raw)) {
                $fallback_value = $fallback_value_raw;
            } else {
                $fallback_value = sanitize_textarea_field((string) $fallback_value_raw);
            }

            $sanitized_fields[] = [
                'target_field' => $target_field,
                'source_path' => $source_path,
                'transform' => $transform,
                'fallback_value' => $fallback_value,
                'is_required' => isset($raw_field['is_required']) && (string) ($raw_field['is_required']) === '1',
            ];
        }

        return [
            'fields' => $sanitized_fields,
        ];
    }

    /**
     * @param array<string, mixed> $raw_filters
     * @param array<string, mixed> $existing_filters
     * @return array<string, mixed>
     */
    private static function sanitize_filters(array $raw_filters, array $existing_filters = [], string $event_name = ''): array
    {
        $source_filters = !empty($raw_filters) ? $raw_filters : $existing_filters;
        if (empty($source_filters)) {
            return [];
        }

        $sanitized_filters = [];
        foreach ($source_filters as $filter_key => $filter_value) {
            $normalized_key = sanitize_key((string) $filter_key);
            if ($normalized_key === '') {
                continue;
            }

            if ($normalized_key === 'chatbot') {
                $chatbot_filter = self::sanitize_scope_filter_definition(is_array($filter_value) ? $filter_value : [], 'bot_ids');
                if (!empty($chatbot_filter)) {
                    $sanitized_filters[$normalized_key] = $chatbot_filter;
                }
                continue;
            }

            if ($normalized_key === 'ai_form') {
                $ai_form_filter = self::sanitize_scope_filter_definition(is_array($filter_value) ? $filter_value : [], 'form_ids');
                if (!empty($ai_form_filter)) {
                    $sanitized_filters[$normalized_key] = $ai_form_filter;
                }
                continue;
            }

            $sanitized_value = self::sanitize_filter_value($filter_value);
            if ($sanitized_value === null) {
                continue;
            }

            $sanitized_filters[$normalized_key] = $sanitized_value;
        }

        if (strpos($event_name, 'chatbot.') !== 0 && isset($sanitized_filters['chatbot'])) {
            unset($sanitized_filters['chatbot']);
        }

        if ($event_name !== 'form.submitted' && isset($sanitized_filters['ai_form'])) {
            unset($sanitized_filters['ai_form']);
        }

        return $sanitized_filters;
    }

    /**
     * @param array<int|string, mixed> $raw_ids
     * @return array<int, int>
     */
    private static function normalize_scope_ids(array $raw_ids): array
    {
        $ids = [];
        foreach ($raw_ids as $raw_id) {
            $id = absint($raw_id);
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @param array<string, mixed> $raw_filter
     * @return array<string, array<int, int>>
     */
    private static function sanitize_scope_filter_definition(array $raw_filter, string $id_key): array
    {
        $ids = self::normalize_scope_ids(
            isset($raw_filter[$id_key]) && is_array($raw_filter[$id_key]) ? $raw_filter[$id_key] : []
        );

        return empty($ids) ? [] : [$id_key => $ids];
    }

    /**
     * @return mixed
     */
    private static function sanitize_filter_value($value)
    {
        if (is_bool($value) || is_int($value) || is_float($value)) {
            return $value;
        }

        if (is_string($value)) {
            return sanitize_text_field($value);
        }

        if (is_array($value)) {
            $sanitized_array = [];
            foreach ($value as $child_key => $child_value) {
                if (is_string($child_key)) {
                    $child_key = sanitize_key($child_key);
                }

                $sanitized_child = self::sanitize_filter_value($child_value);
                if ($sanitized_child === null || $child_key === '') {
                    continue;
                }

                $sanitized_array[$child_key] = $sanitized_child;
            }

            return $sanitized_array;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $recipe
     * @return array<int, int>
     */
    private static function get_scope_filter_ids(array $recipe, string $scope, string $id_key): array
    {
        $filters = isset($recipe['filters']) && is_array($recipe['filters']) ? $recipe['filters'] : [];
        $scope_filter = isset($filters[$scope]) && is_array($filters[$scope]) ? $filters[$scope] : [];

        return self::normalize_scope_ids(
            isset($scope_filter[$id_key]) && is_array($scope_filter[$id_key]) ? $scope_filter[$id_key] : []
        );
    }

    private static function get_chatbot_recipe_scope_label(array $bot_ids, int $active_bot_id): string
    {
        if (empty($bot_ids)) {
            return __('All Chatbots', 'gpt3-ai-content-generator');
        }

        if (count($bot_ids) === 1 && (int) $bot_ids[0] === $active_bot_id) {
            return __('This Chatbot', 'gpt3-ai-content-generator');
        }

        return __('Selected Chatbots', 'gpt3-ai-content-generator');
    }

    private static function get_ai_form_recipe_scope_label(array $form_ids, int $active_form_id): string
    {
        if (empty($form_ids)) {
            return __('All AI Forms', 'gpt3-ai-content-generator');
        }

        if (count($form_ids) === 1 && (int) $form_ids[0] === $active_form_id) {
            return __('This AI Form', 'gpt3-ai-content-generator');
        }

        return __('Selected AI Forms', 'gpt3-ai-content-generator');
    }

    private static function get_recipe_ui_status_label(string $status_key): string
    {
        $labels = [
            'ready' => __('Ready', 'gpt3-ai-content-generator'),
            'warning' => __('Warning', 'gpt3-ai-content-generator'),
            'error' => __('Error', 'gpt3-ai-content-generator'),
            'reauth_required' => __('Reauth required', 'gpt3-ai-content-generator'),
        ];

        return $labels[$status_key] ?? __('Warning', 'gpt3-ai-content-generator');
    }

    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $dispatch_result
     * @param array<string, mixed> $event_context
     */
    public static function recipe_matches_event_filters(
        array $recipe,
        array $event_envelope = [],
        array $dispatch_result = [],
        array $event_context = []
    ): bool {
        $filters = isset($recipe['filters']) && is_array($recipe['filters']) ? $recipe['filters'] : [];
        if (empty($filters)) {
            return true;
        }

        $event_name = sanitize_text_field((string) ($recipe['event_name'] ?? ($event_envelope['type'] ?? '')));
        if (strpos($event_name, 'chatbot.') === 0) {
            $chatbot_filter = isset($filters['chatbot']) && is_array($filters['chatbot']) ? $filters['chatbot'] : [];
            $bot_ids = isset($chatbot_filter['bot_ids']) && is_array($chatbot_filter['bot_ids']) ? $chatbot_filter['bot_ids'] : [];
            if (!empty($bot_ids)) {
                $event_bot_id = self::extract_scope_id_from_event('bot', $event_envelope, $dispatch_result, $event_context);
                if ($event_bot_id <= 0 || !in_array($event_bot_id, array_map('absint', $bot_ids), true)) {
                    return false;
                }
            }
        }

        if ($event_name === 'form.submitted') {
            $ai_form_filter = isset($filters['ai_form']) && is_array($filters['ai_form']) ? $filters['ai_form'] : [];
            $form_ids = isset($ai_form_filter['form_ids']) && is_array($ai_form_filter['form_ids']) ? $ai_form_filter['form_ids'] : [];
            if (!empty($form_ids)) {
                $event_form_id = self::extract_scope_id_from_event('form', $event_envelope, $dispatch_result, $event_context);
                if ($event_form_id <= 0 || !in_array($event_form_id, array_map('absint', $form_ids), true)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $event_envelope
     * @param array<string, mixed> $dispatch_result
     * @param array<string, mixed> $event_context
     */
    private static function extract_scope_id_from_event(
        string $object_key,
        array $event_envelope = [],
        array $dispatch_result = [],
        array $event_context = []
    ): int {
        $payload = isset($event_envelope['data']) && is_array($event_envelope['data']) ? $event_envelope['data'] : [];
        $object = isset($payload[$object_key]) && is_array($payload[$object_key]) ? $payload[$object_key] : [];
        $meta = isset($event_envelope['meta']) && is_array($event_envelope['meta']) ? $event_envelope['meta'] : [];
        $id_key = $object_key . '_id';

        $candidates = [
            $object['id'] ?? 0,
            $meta[$id_key] ?? 0,
            $event_context[$id_key] ?? 0,
            $dispatch_result[$id_key] ?? 0,
        ];

        foreach ($candidates as $candidate) {
            $id = absint($candidate);
            if ($id > 0) {
                return $id;
            }
        }

        return 0;
    }

    private static function normalize_template_slug(string $template_slug): string
    {
        $normalized_slug = sanitize_key($template_slug);
        if ($normalized_slug === '') {
            return '';
        }

        $legacy_aliases = [
            'slack_form_alert' => 'form_submitted_to_slack_message',
            'slack_content_alert' => 'content_generated_to_slack_message',
            'hubspot_form_contact' => 'form_submitted_to_hubspot_contact',
            'notion_content_page' => 'content_generated_to_notion_page',
            'notion_feedback_log' => 'chat_feedback_to_notion_database_item',
            'slack_chat_question' => 'chat_user_message_to_slack_message',
            'slack_chat_response' => 'chat_response_to_slack_message',
        ];

        return $legacy_aliases[$normalized_slug] ?? $normalized_slug;
    }
}
