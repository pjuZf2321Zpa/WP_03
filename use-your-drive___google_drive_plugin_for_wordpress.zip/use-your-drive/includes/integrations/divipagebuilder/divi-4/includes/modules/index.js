import UseyourDrive from './UseyourDrive/UseyourDrive';
import OutoftheBox from './OutoftheBox/OutoftheBox';
import LetsBox from './LetsBox/LetsBox';
import ShareoneDrive from './ShareoneDrive/ShareoneDrive';

export default {
    UseyourDrive,
    OutoftheBox,
    LetsBox,
    ShareoneDrive
};