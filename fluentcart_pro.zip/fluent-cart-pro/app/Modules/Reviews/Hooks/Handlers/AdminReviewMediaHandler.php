<?php

namespace FluentCartPro\App\Modules\Reviews\Hooks\Handlers;

use FluentCart\App\Services\ProductReviewService;
use FluentCart\Framework\Support\Arr;
use FluentCartPro\App\Modules\Reviews\Services\ReviewMediaService;

/**
 * Storage for attachments on admin-authored reviews.
 *
 * The route, the capability and the request validation live in the free
 * plugin beside the other reviews endpoints, so they are covered by the same
 * permission manifest the gate audits. This owns the part free has no code
 * for: putting the bytes on disk and attaching them to the review.
 *
 * Stores and claims in a single request — the review already exists by the
 * time this runs. Nothing is left pending between requests, so there is no
 * orphaned-upload window and no claim token ever reaches the browser. The
 * storefront submission works the same way; both go through
 * ReviewMediaService::storeFilesForReview().
 *
 * Only reachable from a route gated on reviews/manage.
 */
class AdminReviewMediaHandler
{
    public function register()
    {
        add_action('fluent_cart/review/admin_store_media', [$this, 'storeMedia']);
    }

    /**
     * @param array $payload ['review' => ProductReview, 'files' => File[]]
     */
    public function storeMedia($payload)
    {
        $review = isset($payload['review']) ? $payload['review'] : null;
        $files = isset($payload['files']) && is_array($payload['files']) ? $payload['files'] : [];

        if (!$review || empty($review->id) || !$files) {
            return;
        }

        // The store switch, enforced where it counts. The admin modal hides
        // its upload row when photo reviews are off, but a hidden control is
        // not a closed door — this request carries files and arrives at a
        // route that accepts them, so the refusal has to live here too.
        if (Arr::get(ProductReviewService::getReviewSettings(), 'enable_photo_reviews') !== 'yes') {
            return;
        }

        // Same routine the storefront submission runs — one implementation,
        // so the two entry points cannot drift apart.
        ReviewMediaService::storeFilesForReview(
            $review,
            $files,
            ReviewMediaService::buildBucketKey((int) $review->post_id, get_current_user_id(), '')
        );
    }
}
