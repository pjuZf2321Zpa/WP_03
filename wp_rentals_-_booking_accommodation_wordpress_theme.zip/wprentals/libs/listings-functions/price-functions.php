<?php
/**
 * Original price display function that gets data directly from the database
 * 
 * Formats and displays the price for a property with currency symbols and labels
 * Handles both regular pricing and per-guest pricing
 * Supports custom currency conversion based on user preferences
 * 
 * @param int    $post_id               The ID of the property post
 * @param string $wpestate_currency     The currency symbol to use
 * @param string $wpestate_where_currency Whether to show currency before or after amount
 * @param int    $return                Whether to return (1) or print (0) the result
 * @return string|void                  Formatted price string or void if printing
 */
if (!function_exists('wpestate_show_price')):
    function wpestate_show_price($post_id, $wpestate_currency, $wpestate_where_currency, $return = 0) {
        // Get price labels from meta data
        $price_label = '<span class="price_label">' . esc_html(get_post_meta($post_id, 'property_label', true)) . '</span>';
        $property_price_before_label = esc_html(get_post_meta($post_id, 'property_price_before_label', true));
        $property_price_after_label = esc_html(get_post_meta($post_id, 'property_price_after_label', true));
        
        // Reset price label (note: this overwrites the previous price_label)
        $price_label = '';

        // Check if property uses per-guest pricing
        $price_per_guest_from_one = floatval(get_post_meta($post_id, 'price_per_guest_from_one', true));
        
        // Get appropriate price based on pricing model
        if ($price_per_guest_from_one == 1) {
            $price = floatval(get_post_meta($post_id, 'extra_price_per_guest', true));
        } else {
            $price = floatval(get_post_meta($post_id, 'property_price', true));
        }

        // Get currency settings (separators are read inside the formatter)
        $custom_fields = wprentals_get_option('wpestate_currency', '');

        // Handle custom currency if user has selected one
        if (!empty($custom_fields) && 
            isset($_COOKIE['my_custom_curr']) && 
            isset($_COOKIE['my_custom_curr_pos']) && 
            isset($_COOKIE['my_custom_curr_symbol']) && 
            $_COOKIE['my_custom_curr_pos'] != -1) {
            
            $i = floatval($_COOKIE['my_custom_curr_pos']);
            $custom_fields = wprentals_get_option('wpestate_currency', '');
            
            if ($price != 0) {
                // Convert price to custom currency
                $price = $price * floatval($custom_fields[$i][2]);
                
                // Format the price number per the theme formatting options
                $price = wpestate_price_format_number($price);
                
                // Use custom currency symbol
                $wpestate_currency = $custom_fields[$i][1];
                
                // Position currency symbol - no space injected (issue #56)
                $price = wpestate_price_attach_currency($price, $wpestate_currency, $custom_fields[$i][3]);
            } else {
                $price = '';
            }
        } else {
            // Handle default currency display
            if ($price != 0) {
                // Format the price number per the theme formatting options
                $price = wpestate_price_format_number($price);
                
                // Position currency symbol - no space injected (issue #56)
                $price = wpestate_price_attach_currency($price, $wpestate_currency, $wpestate_where_currency);
            } else {
                $price = '';
            }
        }

        // Combine all parts of the price display
        $final_string = trim($property_price_before_label . ' ' . $price . ' ' . $price_label . $property_price_after_label);
        
        // Either print or return the result
        if ($return == 0) {
            print $final_string;
        } else {
            return $final_string;
        }
    }
endif;

/**
 * Optimized price display function that uses pre-cached data
 * 
 * Functions identically to wpestate_show_price but uses cached property data
 * instead of making separate database calls for each piece of information
 * 
 * @param array  $cached_data           Array containing all property meta and data
 * @param string $wpestate_currency     The currency symbol to use
 * @param string $wpestate_where_currency Whether to show currency before or after amount
 * @param int    $return                Whether to return (1) or print (0) the result
 * @return string|void                  Formatted price string or void if printing
 */
if (!function_exists('wpestate_show_price_from_cached_data')):
    function wpestate_show_price_from_cached_data($cached_data, $wpestate_currency, $wpestate_where_currency, $return = 0) {
        // Extract meta data from cached property data
        $meta = (is_array($cached_data) && isset($cached_data['meta']) && is_array($cached_data['meta']))
            ? $cached_data['meta']
            : array();
        
        // Get price labels from cached meta
        $price_label = '<span class="price_label">' . esc_html($meta['property_label'] ?? '') . '</span>';
        $property_price_before_label = esc_html($meta['property_price_before_label'] ?? '');
        $property_price_after_label = esc_html($meta['property_price_after_label'] ?? '');
        $price_label = '';
        
        // Check if property uses per-guest pricing
        $price_per_guest_from_one = floatval($meta['price_per_guest_from_one'] ?? 0);
        
        // Get appropriate price based on pricing model
        if ($price_per_guest_from_one == 1) {
            $price = floatval($meta['extra_price_per_guest'] ?? 0);
        } else {
            $price = floatval($meta['property_price'] ?? 0);
        }

        // Get currency settings (separators are read inside the formatter)
        $custom_fields = wprentals_get_option('wpestate_currency', '');

        // Handle custom currency if user has selected one
        if (!empty($custom_fields) && 
            isset($_COOKIE['my_custom_curr']) && 
            isset($_COOKIE['my_custom_curr_pos']) && 
            isset($_COOKIE['my_custom_curr_symbol']) && 
            $_COOKIE['my_custom_curr_pos'] != -1) {
            
            $i = floatval($_COOKIE['my_custom_curr_pos']);
            
            if ($price != 0) {
                // Convert price to custom currency
                $price = $price * floatval($custom_fields[$i][2]);
                
                // Format the price number per the theme formatting options
                $price = wpestate_price_format_number($price);
                
                // Use custom currency symbol
                $wpestate_currency = $custom_fields[$i][1];
                
                // Position currency symbol - no space injected (issue #56)
                $price = wpestate_price_attach_currency($price, $wpestate_currency, $custom_fields[$i][3]);
            } else {
                $price = '';
            }
        } else {
            // Handle default currency display
            if ($price != 0) {
                // Format the price number per the theme formatting options
                $price = wpestate_price_format_number($price);
                
                // Position currency symbol - no space injected (issue #56)
                $price = wpestate_price_attach_currency($price, $wpestate_currency, $wpestate_where_currency);
            } else {
                $price = '';
            }
        }

        // Combine all parts of the price display
        $final_string = trim($property_price_before_label . ' ' . $price . ' ' . $price_label . $property_price_after_label);
        
        // Either print or return the result
        if ($return == 0) {
            print $final_string;
        } else {
            return $final_string;
        }
    }
endif;

/**
 * Formats a raw price number for display using the Price & Currency theme options.
 *
 * Reads the decimals count, decimal separator and thousands separator options
 * and returns the formatted number string. When the decimals option is set,
 * trailing zeros are kept (99 -> 99.00) — mandatory in some countries.
 *
 * @param float|int|string $price Raw price value
 * @return string                 Formatted number, no currency attached
 */
if (!function_exists('wpestate_price_format_number')):
    function wpestate_price_format_number($price) {
        // Read the formatting options.
        $decimals      = wprentals_get_option('wp_estate_prices_decimals', '');
        $decimal_sep   = wprentals_get_option('wp_estate_prices_decimal_separator', '');
        $th_separator  = wprentals_get_option('wp_estate_prices_th_separator', '');

        // Legacy mode: decimals option never saved — keep the historical
        // behavior of 2 decimals with '.' and trailing zeros trimmed.
        if ($decimals === '' || $decimals === false) {
            $formatted = number_format(floatval($price), 2, '.', $th_separator);
            return wpestate_TrimTrailingZeroes($formatted);
        }

        // Separator option never saved: fall back to '.' so digits never glue.
        if ($decimal_sep === '' || $decimal_sep === false) {
            $decimal_sep = '.';
        }

        // Format with the configured decimals count and separators.
        return number_format(floatval($price), intval($decimals), $decimal_sep, $th_separator);
    }
endif;

/**
 * Attaches the currency symbol to an already formatted price string.
 *
 * No space is injected between symbol and value (issue #56): admins who want
 * a space add it inside the currency symbol theme option itself.
 *
 * @param string $formatted Formatted price number (from wpestate_price_format_number)
 * @param string $symbol    Currency symbol, may carry its own leading/trailing space
 * @param string $where     'before' or 'after' the value
 * @return string           Price with currency attached
 */
if (!function_exists('wpestate_price_attach_currency')):
    function wpestate_price_attach_currency($formatted, $symbol, $where) {
        // Position the symbol on the configured side, nothing added between.
        if ($where == 'before') {
            return $symbol . $formatted;
        } else {
            return $formatted . $symbol;
        }
    }
endif;
