<?php

namespace WPAICG\Lib\Integrations\Recipes;

use WP_Error;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AIPKit_Recipe_Field_Mapper
{
    /**
     * @param array<string, mixed> $recipe
     * @param array<string, mixed> $event_envelope
     * @return array<string, mixed>|WP_Error
     */
    public static function build_mapped_fields(array $recipe, array $event_envelope)
    {
        $mapping = isset($recipe['mapping']) && is_array($recipe['mapping']) ? $recipe['mapping'] : [];
        $fields = isset($mapping['fields']) && is_array($mapping['fields']) ? $mapping['fields'] : [];

        $mapped_fields = [];
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }

            $target_field = sanitize_key((string) ($field['target_field'] ?? ''));
            $source_path = sanitize_text_field((string) ($field['source_path'] ?? ''));
            if ($target_field === '' || $source_path === '') {
                continue;
            }

            $resolved_value = self::get_value_by_path($event_envelope, $source_path);
            if ($resolved_value === null || $resolved_value === '') {
                $resolved_value = $field['fallback_value'] ?? null;
            }

            $resolved_value = self::apply_transform(
                $resolved_value,
                sanitize_key((string) ($field['transform'] ?? ''))
            );

            $is_required = !empty($field['is_required']);
            if ($is_required && ($resolved_value === null || $resolved_value === '')) {
                return new WP_Error(
                    'aipkit_recipe_mapping_required_field_missing',
                    sprintf(
                        /* translators: 1: target field, 2: source path */
                        __('Missing required mapped value for `%1$s` from `%2$s`.', 'gpt3-ai-content-generator'),
                        $target_field,
                        $source_path
                    )
                );
            }

            if ($resolved_value === null || $resolved_value === '') {
                continue;
            }

            $mapped_fields[$target_field] = $resolved_value;
        }

        return $mapped_fields;
    }

    /**
     * @param mixed $payload
     * @return mixed
     */
    private static function get_value_by_path($payload, string $source_path)
    {
        if (!is_array($payload) || $source_path === '') {
            return null;
        }

        $segments = array_values(array_filter(explode('.', $source_path), 'strlen'));
        if (empty($segments)) {
            return null;
        }

        $current = $payload;
        foreach ($segments as $segment) {
            if (is_array($current)) {
                if (array_key_exists($segment, $current)) {
                    $current = $current[$segment];
                    continue;
                }

                if (ctype_digit($segment) && array_key_exists((int) $segment, $current)) {
                    $current = $current[(int) $segment];
                    continue;
                }
            }

            return null;
        }

        return $current;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private static function apply_transform($value, string $transform)
    {
        switch ($transform) {
            case 'json_encode':
                if (is_array($value) || is_object($value)) {
                    return wp_json_encode($value);
                }
                return is_scalar($value) ? (string) $value : '';

            case 'join_lines':
                return self::flatten_to_lines($value);

            case 'yes_no':
                return self::boolish_value($value) ? 'Yes' : 'No';

            case 'lowercase':
                return mb_strtolower(self::stringify_value($value));

            case 'uppercase':
                return mb_strtoupper(self::stringify_value($value));

            default:
                return $value;
        }
    }

    /**
     * @param mixed $value
     */
    public static function stringify_value($value): string
    {
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }

        if (is_scalar($value)) {
            return trim((string) $value);
        }

        if (is_array($value)) {
            return self::flatten_to_lines($value);
        }

        if (is_object($value)) {
            return wp_json_encode($value) ?: '';
        }

        return '';
    }

    /**
     * @param mixed $value
     */
    private static function flatten_to_lines($value): string
    {
        if (!is_array($value)) {
            return self::stringify_value($value);
        }

        $lines = [];
        array_walk_recursive($value, static function ($child) use (&$lines): void {
            if (is_scalar($child)) {
                $line = trim((string) $child);
                if ($line !== '') {
                    $lines[] = $line;
                }
            }
        });

        return implode("\n", $lines);
    }

    /**
     * @param mixed $value
     */
    private static function boolish_value($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (float) $value > 0;
        }

        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'y', 'on'], true);
    }
}
