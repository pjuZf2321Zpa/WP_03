<?php
/** Paid rewrite source, model, instructions and context panels for Automations. */
if (!defined('ABSPATH')) {
    exit;
}

require_once WPAICG_PLUGIN_DIR . 'admin/views/automations/prompt-editor.php';

function aipkit_render_paid_automation_rewrite_panel(string $aipkit_panel, array $aipkit_view_data = []): void
{
    if (!class_exists('\\WPAICG\\aipkit_dashboard') || !\WPAICG\aipkit_dashboard::is_pro_plan()) {
        return;
    }
    if ($aipkit_panel === 'model') {
        require_once WPAICG_PLUGIN_DIR . 'admin/views/automations/model-settings.php';
        aipkit_render_automation_model_settings([
            'scope' => 'ce',
            'name_prefix' => 'ce_',
            'max_tokens_question' => __('Maximum rewrite length', 'gpt3-ai-content-generator'),
            'has_max_tokens' => true,
            'default_max_tokens' => $aipkit_view_data['cw_default_max_tokens'] ?? '4000',
        ], $aipkit_view_data);
        return;
    }
    if ($aipkit_panel === 'context') {
        require_once WPAICG_PLUGIN_DIR . 'admin/views/automations/context-settings.php';
        aipkit_render_automation_context_settings([
            'scope' => 'ce',
            'name_prefix' => 'ce_',
            'root_classes' => 'aipkit_cw_vector_section aipkit_task_cw_kb_section aipkit_task_ce_kb_section',
            'embedding_context' => 'autogpt_content_enhancement_ui',
        ], $aipkit_view_data);
        return;
    }
    if ($aipkit_panel === 'source') {
        $all_selectable_post_types = $aipkit_view_data['all_selectable_post_types'] ?? [];
        $cw_wp_categories = $aipkit_view_data['cw_wp_categories'] ?? [];
        $cw_users_for_author = $aipkit_view_data['cw_users_for_author'] ?? [];
        ?>
        <div class="aipkit_ce_source_grid aipkit_ce_source_grid--primary">
            <section class="aipkit_ce_filter_card aipkit_ce_filter_row">
                <div class="aipkit_ce_filter_card_header">
                    <label class="aipkit_ce_filter_card_title" for="aipkit_task_ce_post_types"><?php esc_html_e('Content types', 'gpt3-ai-content-generator'); ?></label>
                </div>
                <select id="aipkit_task_ce_post_types" name="ce_post_types[]" class="aipkit_form-input aipkit_ce_multi_select" data-aipkit-checklist-style="inline-checkboxes" multiple size="5">
                    <?php foreach ($all_selectable_post_types as $slug => $pt_obj): ?>
                        <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($pt_obj->label); ?></option>
                    <?php endforeach; ?>
                </select>
            </section>
        
            <?php // Keep the saved status in the form without exposing another setup choice. New tasks default to published content. ?>
            <select id="aipkit_task_ce_post_status" name="ce_post_statuses[]" multiple hidden aria-hidden="true">
                <option value="publish" selected><?php esc_html_e('Published', 'gpt3-ai-content-generator'); ?></option>
                <option value="draft"><?php esc_html_e('Draft', 'gpt3-ai-content-generator'); ?></option>
                <option value="pending"><?php esc_html_e('Pending Review', 'gpt3-ai-content-generator'); ?></option>
            </select>
        </div>
        
        <div class="aipkit_ce_source_grid aipkit_ce_source_grid--optional">
            <section class="aipkit_ce_filter_card aipkit_ce_filter_card--optional aipkit_ce_filter_row">
                <div class="aipkit_ce_filter_card_header">
                    <label class="aipkit_ce_filter_card_title" for="aipkit_task_ce_post_categories"><?php esc_html_e('Categories', 'gpt3-ai-content-generator'); ?></label>
                </div>
                <select id="aipkit_task_ce_post_categories" name="ce_post_categories[]" class="aipkit_form-input aipkit_ce_multi_select" data-aipkit-checklist-style="inline-checkboxes" multiple size="5">
                    <?php foreach ($cw_wp_categories as $category): ?>
                        <option value="<?php echo esc_attr($category->term_id); ?>"><?php echo esc_html($category->name); ?></option>
                    <?php endforeach; ?>
                </select>
            </section>
        
            <section class="aipkit_ce_filter_card aipkit_ce_filter_card--optional aipkit_ce_filter_row">
                <div class="aipkit_ce_filter_card_header">
                    <label class="aipkit_ce_filter_card_title" for="aipkit_task_ce_post_authors"><?php esc_html_e('Authors', 'gpt3-ai-content-generator'); ?></label>
                </div>
                <select id="aipkit_task_ce_post_authors" name="ce_post_authors[]" class="aipkit_form-input aipkit_ce_multi_select" data-aipkit-checklist-style="inline-checkboxes" multiple size="5">
                    <?php foreach ($cw_users_for_author as $user): ?>
                        <option value="<?php echo esc_attr($user->ID); ?>"><?php echo esc_html($user->display_name); ?></option>
                    <?php endforeach; ?>
                </select>
            </section>
        </div>
        
        <section id="aipkit_task_ce_queue_now_card" class="aipkit_ce_filter_card aipkit_ce_filter_row aipkit_ce_queue_card aipkit_ce_queue_card--inline">
            <div class="aipkit_ce_filter_card_header aipkit_ce_queue_card_header">
                <label class="aipkit_ce_filter_card_title" for="aipkit_task_ce_enhance_existing_now_flag"><?php esc_html_e('Include existing content', 'gpt3-ai-content-generator'); ?></label>
                <span class="aipkit_ce_queue_toggle_desc"><?php esc_html_e('Add current matches now; otherwise only newly eligible content is processed.', 'gpt3-ai-content-generator'); ?></span>
            </div>
            <label class="aipkit_switch aipkit_ce_queue_switch" for="aipkit_task_ce_enhance_existing_now_flag">
                <input type="checkbox" id="aipkit_task_ce_enhance_existing_now_flag" name="ce_enhance_existing_now_flag" value="1">
                <span class="aipkit_switch_slider"></span>
            </label>
        </section>
        <?php
        return;
    }
    if ($aipkit_panel !== 'prompts') {
        return;
    }
    $aipkit_ce_prompt_items = \WPAICG\AutoGPT\Helpers\AIPKit_AutoGPT_Prompt_Definitions::get_content_enhancement_prompt_items();
    
    foreach ($aipkit_ce_prompt_items as &$aipkit_ce_prompt_item) {
        if (!empty($aipkit_ce_prompt_item['toggle']['name'])) {
            $aipkit_ce_prompt_item['visibility_control'] = (string) $aipkit_ce_prompt_item['toggle']['name'];
        }
        $aipkit_ce_prompt_item['static_placeholders'] = true;
    }
    unset($aipkit_ce_prompt_item);
    ?>
    
    <div class="aipkit_cw_publishing_row">
        <label class="aipkit_cw_panel_label" for="aipkit_task_ce_post_content_format"><?php esc_html_e('Content format', 'gpt3-ai-content-generator'); ?></label>
        <select id="aipkit_task_ce_post_content_format" name="ce_post_content_format" class="aipkit_form-input">
            <option value="gutenberg"><?php esc_html_e('Gutenberg', 'gpt3-ai-content-generator'); ?></option>
            <option value="html"><?php esc_html_e('Classic', 'gpt3-ai-content-generator'); ?></option>
        </select>
    </div>
    <div
        class="aipkit_autogpt_content_fields"
        data-aipkit-inline-prompts="rewrite"
        data-aipkit-inline-prompt-layout="rows"
    >
        <?php foreach ($aipkit_ce_prompt_items as $aipkit_ce_prompt_item) : ?>
            <?php
            $aipkit_ce_prompt_key = sanitize_key((string) ($aipkit_ce_prompt_item['key'] ?? ''));
            $aipkit_ce_prompt_label = (string) ($aipkit_ce_prompt_item['label'] ?? '');
            $aipkit_ce_prompt_toggle = isset($aipkit_ce_prompt_item['toggle']) && is_array($aipkit_ce_prompt_item['toggle'])
                ? $aipkit_ce_prompt_item['toggle']
                : [];
            $aipkit_ce_has_toggle = !empty($aipkit_ce_prompt_toggle['id']) && !empty($aipkit_ce_prompt_toggle['name']);
            $aipkit_ce_toggle_checked = !$aipkit_ce_has_toggle || !empty($aipkit_ce_prompt_toggle['checked']);
            $aipkit_ce_visibility_control = (string) ($aipkit_ce_prompt_item['visibility_control'] ?? '');
            $aipkit_ce_prompt_panel_id = 'aipkit_task_ce_' . $aipkit_ce_prompt_key . '_instruction_panel';
            if ($aipkit_ce_prompt_key === '' || $aipkit_ce_prompt_label === '') {
                continue;
            }
            ?>
            <div
                class="aipkit_autogpt_content_field"
                data-aipkit-content-field
                data-aipkit-prompt-key="<?php echo esc_attr($aipkit_ce_prompt_key); ?>"
                <?php echo $aipkit_ce_visibility_control !== '' ? ' data-aipkit-visibility-control="' . esc_attr($aipkit_ce_visibility_control) . '"' : ''; ?>
            >
                <div class="aipkit_autogpt_content_field_row">
                    <span class="aipkit_autogpt_content_field_label_wrap">
                        <span class="aipkit_autogpt_content_field_label"><?php echo esc_html($aipkit_ce_prompt_label); ?></span>
                    </span>
                    <div class="aipkit_autogpt_content_field_controls">
                        <button
                            type="button"
                            class="aipkit_autogpt_content_prompt_trigger"
                            data-aipkit-row-prompt-toggle
                            aria-controls="aipkit_task_ce_instructions_modal"
                            aria-haspopup="dialog"
                            <?php echo $aipkit_ce_toggle_checked ? '' : ' hidden'; ?>
                        >
                            <span
                                data-aipkit-row-prompt-status
                                data-built-in-label="<?php esc_attr_e('Instructions', 'gpt3-ai-content-generator'); ?>"
                                data-custom-label="<?php esc_attr_e('Custom instructions', 'gpt3-ai-content-generator'); ?>"
                            ><?php esc_html_e('Instructions', 'gpt3-ai-content-generator'); ?></span>
                            <span class="dashicons dashicons-edit aipkit_autogpt_content_prompt_icon" aria-hidden="true"></span>
                        </button>
    
                        <?php if ($aipkit_ce_has_toggle) : ?>
                            <label class="aipkit_switch aipkit_autogpt_content_field_switch" aria-label="<?php
                            /* translators: %s: content field name. */
                            echo esc_attr(sprintf(__('Update %s', 'gpt3-ai-content-generator'), $aipkit_ce_prompt_label));
                            ?>">
                                <input
                                    type="checkbox"
                                    id="<?php echo esc_attr((string) $aipkit_ce_prompt_toggle['id']); ?>"
                                    name="<?php echo esc_attr((string) $aipkit_ce_prompt_toggle['name']); ?>"
                                    value="1"
                                    <?php checked(!empty($aipkit_ce_prompt_toggle['checked'])); ?>
                                >
                                <span class="aipkit_switch_slider"></span>
                            </label>
                        <?php endif; ?>
                    </div>
                </div>
    
                <div
                    id="<?php echo esc_attr($aipkit_ce_prompt_panel_id); ?>"
                    class="aipkit_autogpt_content_prompt_panel"
                    data-aipkit-row-prompt-panel
                    hidden
                >
                    <?php
                    aipkit_render_automation_prompt_editor([$aipkit_ce_prompt_item]);
                    ?>
                </div>
            </div>
        <?php endforeach; ?>
    
        <div
            id="aipkit_task_ce_instructions_modal"
            class="aipkit_autogpt_instructions_modal"
            data-aipkit-instructions-modal
            data-title-template="<?php
            /* translators: %s: content field name. */
            echo esc_attr(__('%s instructions', 'gpt3-ai-content-generator'));
            ?>"
            aria-hidden="true"
            hidden
        >
            <div
                class="aipkit_autogpt_instructions_modal_panel"
                role="dialog"
                aria-modal="true"
                aria-labelledby="aipkit_task_ce_instructions_modal_title"
                aria-describedby="aipkit_task_ce_instructions_modal_description"
            >
                <div class="aipkit_autogpt_instructions_modal_header">
                    <div class="aipkit_autogpt_instructions_modal_heading">
                        <h2 id="aipkit_task_ce_instructions_modal_title" data-aipkit-instructions-modal-title>
                            <?php esc_html_e('Instructions', 'gpt3-ai-content-generator'); ?>
                        </h2>
                        <p id="aipkit_task_ce_instructions_modal_description">
                            <?php esc_html_e('Tell AI how to rewrite this part of every post.', 'gpt3-ai-content-generator'); ?>
                        </p>
                    </div>
                    <button
                        type="button"
                        class="aipkit_autogpt_instructions_modal_close"
                        data-aipkit-instructions-modal-close
                        aria-label="<?php esc_attr_e('Close instructions', 'gpt3-ai-content-generator'); ?>"
                    >
                        <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                    </button>
                </div>
                <div class="aipkit_autogpt_instructions_modal_body" data-aipkit-instructions-modal-body></div>
                <div class="aipkit_autogpt_instructions_modal_footer">
                    <button type="button" class="aipkit_btn aipkit_btn-secondary" data-aipkit-instructions-modal-cancel>
                        <?php esc_html_e('Cancel', 'gpt3-ai-content-generator'); ?>
                    </button>
                    <button type="button" class="aipkit_btn aipkit_btn-primary" data-aipkit-instructions-modal-save>
                        <?php esc_html_e('Save', 'gpt3-ai-content-generator'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php
}
