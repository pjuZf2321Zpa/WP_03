<?php

namespace BitApps\IntegrationsPro\Actions\FollowUpBoss\Services;

final class EventService extends BaseService
{
    public function createEvent(): array
    {
        $validationRules = [
            'event_type'           => ['required'],
            'property_price'       => ['nullable', 'integer'],
            'search_min_price'     => ['nullable', 'integer'],
            'search_max_price'     => ['nullable', 'integer'],
            'search_min_bedrooms'  => ['nullable', 'integer'],
            'search_max_bedrooms'  => ['nullable', 'integer'],
            'search_min_bathrooms' => ['nullable', 'numeric'],
            'search_max_bathrooms' => ['nullable', 'numeric'],
            'page_duration'        => ['nullable', 'integer'],
        ];
        $error = $this->validateFields(
            $validationRules,
            [
                'event_type'           => __('Event Type', 'bit-integrations-pro'),
                'property_price'       => __('Property Price', 'bit-integrations-pro'),
                'search_min_price'     => __('Search Minimum Price', 'bit-integrations-pro'),
                'search_max_price'     => __('Search Maximum Price', 'bit-integrations-pro'),
                'search_min_bedrooms'  => __('Search Minimum Bedrooms', 'bit-integrations-pro'),
                'search_max_bedrooms'  => __('Search Maximum Bedrooms', 'bit-integrations-pro'),
                'search_min_bathrooms' => __('Search Minimum Bathrooms', 'bit-integrations-pro'),
                'search_max_bathrooms' => __('Search Maximum Bathrooms', 'bit-integrations-pro'),
                'page_duration'        => __('Page Duration', 'bit-integrations-pro'),
            ],
            ['event_type']
        );

        if ($error !== null) {
            return $error;
        }

        $payload = $this->removeEmptyValues(
            [
                'type'        => $this->getString('event_type'),
                'source'      => $this->getString('source'),
                'system'      => $this->getString('system'),
                'message'     => $this->getString('message'),
                'description' => $this->getString('description'),
                'occurredAt'  => $this->getString('occurred_at'),
                'person'      => $this->removeEmptyValues(
                    [
                        'id'             => $this->getInteger('person_id'),
                        'firstName'      => $this->getString('person_first_name'),
                        'lastName'       => $this->getString('person_last_name'),
                        'stage'          => $this->getString('person_stage'),
                        'tags'           => $this->getList('person_tags'),
                        'assignedUserId' => $this->getInteger('person_assigned_user_id'),
                        'emails'         => $this->getEmails('person_email'),
                        'phones'         => $this->getPhones('person_phone'),
                    ]
                ),
                'property' => $this->removeEmptyValues(
                    [
                        'street'    => $this->getString('property_street'),
                        'city'      => $this->getString('property_city'),
                        'state'     => $this->getString('property_state'),
                        'code'      => $this->getString('property_code'),
                        'mlsNumber' => $this->getString('property_mls_number'),
                        'price'     => $this->getInteger('property_price'),
                        'forRent'   => $this->getBoolean('property_for_rent'),
                        'url'       => $this->getString('property_url'),
                        'type'      => $this->getString('property_type'),
                        'bedrooms'  => $this->getString('property_bedrooms'),
                        'bathrooms' => $this->getString('property_bathrooms'),
                        'area'      => $this->getString('property_area'),
                        'lot'       => $this->getString('property_lot'),
                    ]
                ),
                'propertySearch' => $this->removeEmptyValues(
                    [
                        'type'         => $this->getString('search_type'),
                        'neighborhood' => $this->getString('search_neighborhood'),
                        'city'         => $this->getString('search_city'),
                        'state'        => $this->getString('search_state'),
                        'code'         => $this->getString('search_code'),
                        'minPrice'     => $this->getInteger('search_min_price'),
                        'maxPrice'     => $this->getInteger('search_max_price'),
                        'minBedrooms'  => $this->getInteger('search_min_bedrooms'),
                        'maxBedrooms'  => $this->getInteger('search_max_bedrooms'),
                        'minBathrooms' => $this->getNumber('search_min_bathrooms'),
                        'maxBathrooms' => $this->getNumber('search_max_bathrooms'),
                    ]
                ),
                'campaign' => $this->removeEmptyValues(
                    [
                        'source'   => $this->getString('campaign_source'),
                        'medium'   => $this->getString('campaign_medium'),
                        'term'     => $this->getString('campaign_term'),
                        'content'  => $this->getString('campaign_content'),
                        'campaign' => $this->getString('campaign_name'),
                    ]
                ),
                'pageTitle'    => $this->getString('page_title'),
                'pageUrl'      => $this->getString('page_url'),
                'pageReferrer' => $this->getString('page_referrer'),
                'pageDuration' => $this->getInteger('page_duration'),
            ]
        );

        return $this->dispatch('POST', '/events', $payload);
    }
}
