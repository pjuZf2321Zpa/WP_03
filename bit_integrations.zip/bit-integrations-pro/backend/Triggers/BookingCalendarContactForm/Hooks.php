<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\IntegrationsPro\Core\Util\Hooks;
use BitApps\IntegrationsPro\Triggers\BookingCalendarContactForm\BookingCalendarContactFormController;

Hooks::add('dexbccf_process_data', [BookingCalendarContactFormController::class, 'handleFormSubmitted'], 99);
