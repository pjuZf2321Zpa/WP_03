<?php

namespace FluentBookingPro\App\Services\Captcha;

use FluentBooking\App\Services\Helper;
use FluentBooking\Framework\Support\Arr;

abstract class AbstractCaptchaProvider
{
    /**
     * Stands in for a stored secret in the admin UI. The same value on save
     * means "keep the stored secret".
     */
    const SECRET_MASK = '__FCAL_CAPTCHA_SECRET__';

    abstract public function getKey();

    abstract public function getTitle();

    abstract public function getDefaults();

    abstract public function sanitize($input, $prev = []);

    /**
     * The secret field names this provider stores, encrypted.
     *
     * @return array
     */
    abstract public function secretFields();

    abstract public function isConfigured($settings);

    /**
     * The data the public booking app needs to render the widget.
     *
     * @param array $settings
     * @return array
     */
    abstract public function publicVars($settings);

    /**
     * @param array  $settings
     * @param string $token
     * @return array ['status' => valid|invalid|unreachable, 'code' => string]
     */
    abstract public function verify($settings, $token);

    /**
     * @param array  $settings
     * @param string $token
     * @return array ['valid' => bool, 'message' => string]
     */
    abstract public function validateCredentials($settings, $token);

    /**
     * Replace every stored secret with the mask before the settings reach the browser.
     *
     * @param array $settings
     * @return array
     */
    public function maskSecrets($settings)
    {
        foreach ($this->secretFields() as $field) {
            if (!empty($settings[$field])) {
                $settings[$field] = self::SECRET_MASK;
            }
        }

        return $settings;
    }

    /**
     * Encrypt an incoming secret, or keep the stored one when the UI sent the mask back.
     *
     * @param string $incoming
     * @param string $prevEncrypted
     * @return string
     */
    protected function resolveSecret($incoming, $prevEncrypted)
    {
        $incoming = trim((string)$incoming);

        // Keep what is stored when the field says nothing new: an empty or
        // omitted field means "unchanged", the mask is what the admin UI sends
        // back, and the ciphertext itself arrives on a save(getSettings())
        // round trip, which would otherwise encrypt the key a second time.
        if ($incoming === '' || $incoming === self::SECRET_MASK || ($prevEncrypted && $incoming === (string)$prevEncrypted)) {
            return (string)$prevEncrypted;
        }

        return (string)Helper::encryptKey(sanitize_text_field($incoming));
    }

    /**
     * @param string $stored
     * @return string
     */
    protected function decryptSecret($stored)
    {
        return $stored ? (string)Helper::decryptKey($stored) : '';
    }

    /**
     * Post to a provider's siteverify endpoint.
     *
     * A WP_Error, a timeout or an HTTP 5xx is an outage, never a rejection: the
     * booking is accepted when the provider cannot answer.
     *
     * @param string $url
     * @param array  $body
     * @param int    $attempts
     * @return array ['unreachable' => bool, 'reason' => string, 'result' => array|null]
     */
    protected function remoteVerify($url, $body, $attempts = 2)
    {
        $response = null;

        for ($attempt = 1; $attempt <= max(1, $attempts); $attempt++) {
            $response = wp_remote_post($url, [ // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- server-side captcha token verification
                'body'    => $body,
                'timeout' => 5,
            ]);

            if (!is_wp_error($response) && (int)wp_remote_retrieve_response_code($response) < 500) {
                break;
            }
        }

        if (is_wp_error($response)) {
            return [
                'unreachable' => true,
                'reason'      => $response->get_error_message(),
                'result'      => null,
            ];
        }

        $status = (int)wp_remote_retrieve_response_code($response);

        if ($status >= 500) {
            return [
                'unreachable' => true,
                'reason'      => 'HTTP ' . $status,
                'result'      => null,
            ];
        }

        $result = json_decode(wp_remote_retrieve_body($response), true);

        if (!is_array($result)) {
            return [
                'unreachable' => true,
                'reason'      => 'Unreadable response from the provider',
                'result'      => null,
            ];
        }

        return [
            'unreachable' => false,
            'reason'      => '',
            'result'      => $result,
        ];
    }

    /**
     * Turn the provider's error codes into one of the three results.
     *
     * A wrong secret key is a setup error, not a bot: it fails open, so a bad
     * key does not block every booking on the site.
     *
     * @param array $result
     * @return array
     */
    protected function resultFromErrorCodes($result)
    {
        $codes = array_map('strval', (array)Arr::get($result, 'error-codes', []));

        if (in_array('invalid-input-secret', $codes, true) || in_array('missing-input-secret', $codes, true)) {
            return [
                'status' => 'unreachable',
                'code'   => 'invalid_secret',
                'reason' => 'The captcha secret key was refused by the provider.',
            ];
        }

        if (in_array('timeout-or-duplicate', $codes, true)) {
            return [
                'status' => 'invalid',
                'code'   => 'captcha_expired',
            ];
        }

        return [
            'status' => 'invalid',
            'code'   => 'captcha_failed',
        ];
    }

    /**
     * @return string
     */
    protected function getIpAddress()
    {
        return (string)Helper::getIp();
    }
}
