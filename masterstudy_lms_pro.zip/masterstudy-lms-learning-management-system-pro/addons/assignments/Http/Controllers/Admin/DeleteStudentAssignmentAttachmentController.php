<?php

namespace MasterStudy\Lms\Pro\addons\assignments\Http\Controllers\Admin;

use MasterStudy\Lms\Http\WpResponseFactory;
use MasterStudy\Lms\Plugin\PostType;
use MasterStudy\Lms\Pro\addons\assignments\Repositories\AssignmentAttachmentRepository;
use WP_REST_Request;
use WP_REST_Response;

final class DeleteStudentAssignmentAttachmentController {
	public function __invoke( int $student_assignment_id, int $attachment_id, WP_REST_Request $request ): WP_REST_Response {
		if ( $student_assignment_id <= 0 || PostType::USER_ASSIGNMENT !== get_post_type( $student_assignment_id ) ) {
			return WpResponseFactory::not_found();
		}

		if ( $attachment_id <= 0 || ! get_post( $attachment_id ) ) {
			return WpResponseFactory::not_found();
		}

		$repository = new AssignmentAttachmentRepository();
		$deleted    = $repository->delete_instructor_attachment( $student_assignment_id, $attachment_id );

		if ( ! $deleted ) {
			return WpResponseFactory::bad_request( 'Failed to delete attachment.' );
		}

		return WpResponseFactory::ok();
	}
}
