<?php

namespace BitApps\IntegrationsPro\Actions\Booknetic\Services;

use BookneticApp\Models\Customer;
use BookneticApp\Models\CustomerCategory;

final class CustomerCategoryService extends BaseService
{
    private const DEFAULT_COLOR = '#6c70dc';

    public function createCustomerCategory(): array
    {
        $error = $this->validate(['name' => [__('Name', 'bit-integrations-pro')]]);

        if ($error !== null) {
            return $error;
        }

        $data = $this->categoryData() + ['color' => self::DEFAULT_COLOR, 'icon' => '', 'note' => '', 'is_default' => 0];
        $result = $this->createRecord(CustomerCategory::class, $data);

        if ($result['success'] && !empty($data['is_default'])) {
            self::clearOtherDefaults((int) $result['data']['id']);
        }

        return $result;
    }

    public function updateCustomerCategory(): array
    {
        $error = $this->validate(['customer_category_id' => [__('Customer Category ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $categoryId = $this->int('customer_category_id');
        $data = $this->categoryData();
        $result = $this->updateRecord(CustomerCategory::class, $categoryId, $data);

        if ($result['success'] && !empty($data['is_default'])) {
            self::clearOtherDefaults($categoryId);
        }

        return $result;
    }

    public function deleteCustomerCategory(): array
    {
        $error = $this->validate(['customer_category_id' => [__('Customer Category ID', 'bit-integrations-pro'), 'integer']]);

        if ($error !== null) {
            return $error;
        }

        $categoryId = $this->int('customer_category_id');

        if (Customer::query()->where('category_id', $categoryId)->count() > 0) {
            return $this->error(__('The category has customers. Move the customers to a different category first.', 'bit-integrations-pro'), 422);
        }

        return $this->deleteRecord(CustomerCategory::class, $categoryId, __('The customer category is deleted.', 'bit-integrations-pro'));
    }

    private function categoryData(): array
    {
        $data = $this->optionalTextFields(['name' => 'name', 'color' => 'color', 'icon' => 'icon', 'note' => 'note']);

        if ($this->has('is_default')) {
            $data['is_default'] = (int) $this->toBool($this->value('is_default'));
        }

        return $data;
    }

    private static function clearOtherDefaults(int $categoryId): void
    {
        CustomerCategory::query()->where('id', '!=', $categoryId)->update(['is_default' => 0]);
    }
}
